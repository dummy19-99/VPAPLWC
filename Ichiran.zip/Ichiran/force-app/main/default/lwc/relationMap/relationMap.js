import {LightningElement, wire, api} from 'lwc';
import {loadScript, loadStyle} from 'lightning/platformResourceLoader';
import {CurrentPageReference} from 'lightning/navigation';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {getRecord, getFieldValue, deleteRecord} from 'lightning/uiRecordApi';
import relationMapResource from '@salesforce/resourceUrl/relationMap';
import getRelations from '@salesforce/apex/LWC_relationMap.getRelations';
import FROMSELECTION_FIELD from '@salesforce/schema/RelationMap__c.FromSelection__c';
import TOSELECTION_FIELD from '@salesforce/schema/RelationMap__c.ToSelection__c';

const formSelectionFeilds = [FROMSELECTION_FIELD, TOSELECTION_FIELD];

export default class RelationMap extends LightningElement {
  /*******
   * Component properties
   *******/
  @api height;
  @api nodeText;
  @api tooltipText;
  @api searchHierarchy;
  @api flexipageRegionWidth; // Component Width ex. LARGE
  @api objectApiName; // Object Name
  @api recordId; //RecordId

  /*******
   * Score Color
   *******/
  @api score0;
  @api score1;
  @api score2;
  @api score3;
  @api score4;
  @api score5;
  @api score6;
  @api score7;
  @api score8;
  @api score9;
  @api score10;
  @api colorSet;

  //Old @track
  recordData;
  fromSelectValue;

  //D3で使用するParameter
  d3Initialized = false;
  parameters = {};
  loaded = true;
  device;
  editTaregtId;
  scoreValue;
  isDesktop;
  _minSvgHeight = 300;
  _defaultSize = 1000;
  _lineDistance = 100;
  _recordData = {};
  _rSize = 40;

  editFormArea;
  root;
  container;
  containerInfo;
  containerWidth;
  containerHeight;
  resetZoomPosition = {};

  tq(selector) {
    return this.template.querySelector(selector);
  }

  tqa(selector) {
    return this.template.querySelectorAll(selector);
  }

  /*****
   * Edit Form Action
   * UIで設定した内容をレコードに反映
  *****/
  editSubmit(e) {
    e.preventDefault();
    const fields = e.detail.fields;
    const selectFromTo = {
      from: fields.FromSelection__c,
      to: fields.ToSelection__c
    };
    const fieldsFromList = ['FromAccount__c', 'FromContact__c', 'FromLead__c', 'FromUser__c', 'FromCustom__c'];
    const fieldsToList = ['ToAccount__c', 'ToContact__c', 'ToLead__c', 'ToUser__c', 'ToCustom__c'];

    const fromCLockup = this.tq('.from-c-lookup').getSelection();
    const toCLockup = this.tq('.to-c-lookup').getSelection();

    //送信前に必須項目を入力する
    //該当しないfieldは空にする
    fields.From__c = null;
    fields.To__c = null;

    if (this.isDesktop) {
      // Desctop Action
      fieldsFromList.forEach(val => {
        if (`From${selectFromTo.from.replace('__c', '')}__c` === val) {
          fields.From__c = fields[val];
        } else {
          fields[val] = null;
        }
      });

      fieldsToList.forEach(val => {
        if (`To${selectFromTo.to.replace('__c', '')}__c` === val) {
          fields.To__c = fields[val];
        } else {
          fields[val] = null;
        }
      });
    } else {
      // Mobile Action
      if (fromCLockup && fromCLockup[0]) {
        let fromType = fromCLockup[0].sObjectType;

        if (/Custom__c$/.test(fromType)) {
          fromType = 'Custom__c';
        }

        fieldsFromList.forEach(val => {
          if (`From${fromType.replace('__c', '')}__c` === val) {
            fields.From__c = fromCLockup[0].id;
            fields[val] = fromCLockup[0].id;
          } else {
            fields[val] = null;
          }
        });
      }
      if (toCLockup && toCLockup[0]) {
        let toType = toCLockup[0].sObjectType;
        if (/Custom__c$/.test(toType)) {
          toType = 'Custom__c';
        }
        fieldsToList.forEach(val => {
          if (`To${toType.replace('__c', '')}__c` === val) {
            fields.To__c = toCLockup[0].id;
            fields[val] = toCLockup[0].id;
          } else {
            fields[val] = null;
          }
        });
      }
    }

    fields.Score__c = this.scoreValue;

    if (fields.From__c == null || fields.To__c == null) {
      this.showToast('error', 'Error', '選択した内容の確認をお願いします。');
    } else {
      this.tq('lightning-record-edit-form').submit(fields);
    }
  }

  /*****
   * lightning-record-edit-formのload時に呼び出し
  *****/
  handleEditLoad() {
    if (this.editTaregtId && this.recordData) {
      const link = this.recordData.link;

      for (const lItem of link) {
        if (lItem.Id === this.editTaregtId) {
          this.scoreValue = parseInt(lItem.score, 10);
        }
      }
    } else {
      this.scoreValue = 5;
    }

    this.setScore({});
  }

  /*****
   * リレーションのスコアを設定
  *****/
  setScore({target}) {
    if (target && target.value) {
      this.scoreValue = parseInt(target.value, 10);
    }

    const setectTargetList = this.tqa('[data-score-val]');

    for (const list of setectTargetList) {
      if (parseInt(list.dataset.scoreVal, 10) === this.scoreValue) {
        list.classList.add('selected');
      } else {
        list.classList.remove('selected');
      }
    }
  }

  /*****
   * lightning-record-edit-formの送信完了後に実行
  *****/
  editSuccess() {
    this.showToast('success', 'Success', 'データの保存が完了しました。');
    this.refreshContent();
  }

  /*****
   * トーストの表示
  *****/
  showToast(type, title, message) {
    this.dispatchEvent(
      new ShowToastEvent({
        title: title,
        message: message,
        variant: type,
      }),
    );
  }

  /*****
   * 編集エリアのInputの表示制御
  *****/
  setViewField(fromto, val) {
    const targetObject = ['Account', 'Contact', 'Lead', 'User', 'Custom'];

    targetObject.forEach(target => {
      let targetElm;

      if (this.tq(`.From${target}`) && ('From' === fromto)) {
        targetElm = this.tq(`.From${target}`);
      }

      if (this.tq(`.To${target}`) && ('To' === fromto)) {
        targetElm = this.tq(`.To${target}`);
      }

      if (targetElm) {
        targetElm.classList.add('hide');
        targetElm.reset();
      }
    });

    if (fromto && val) {
      this.tq(`.${fromto}${val}`).classList.remove('hide');
    }
  }

  /*****
   * 編集エリアのFromのSelectBoxの値が切り替えられた場合に実行
  *****/
  handleFromSelectionChange(e) {
    this.setViewField('From', e.detail.value);
  }

  /*****
   * 編集エリアのToのSelectBoxの値が切り替えられた場合に実行
  *****/
  handleToSelectionChange(e) {
    this.setViewField('To', e.detail.value);
  }

  /*****
   * 編集対象リレーションが変更された場合に実行
  *****/
  @wire(getRecord, {recordId: '$editTaregtId', fields: formSelectionFeilds})
  selectiondata({error, data}) {
    if (data) {
      this.fromSelectValue = getFieldValue(data, FROMSELECTION_FIELD);
      this.toSelectValue = getFieldValue(data, TOSELECTION_FIELD);
      this.setViewField('From', this.fromSelectValue);
      this.setViewField('To', this.toSelectValue);
    } else if (error) {
      console.error('error', error);
      this.showToast('error', 'Error', 'データの取得でエラーが発生しました。 [ERROR_CODE-2]');
    }
  }

  get fromValue() {
    return this.fromSelectValue;
  }

  get toValue() {
    return this.toSelectValue;
  }

  /*****
   * Get URL Param
   * URLのクエリストリングの取得
   * VFでラップした場合に使用
  *****/
  getQueryParameters() {
    const search = location.search.substring(1);
    let params = {};

    if (search) {
      params = JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', (key, value) => {
        return key === '' ? value : decodeURIComponent(value)
      });
    }

    return params;
  }

  /*****
   * Get Record Data
  *****/
  getData() {
    if (!this.recordId) {
      this.showToast('error', 'Error', 'レコードIDが取得できませんでした。');
      return false;
    }

    /*****
     * Apex Action
     * データ取得後にNodeとLinkを洗い替え
     * String recordId
     * Integer deep
    *****/
    return getRelations({
      recordId: this.recordId,
      deep: this.searchHierarchy || 5
    }).then(data => {
      const d3Data = {};
      const d3NodeData = [];
      const d3LinkData = [];
      const originalData = JSON.parse(data);
      const originalNodeData = originalData.node;
      const originalLinkData = originalData.link;

      for (let i = 0; i < originalNodeData.length; i++) {
        let tmpNodeData = originalNodeData[i];

        let imageFileName = tmpNodeData.attributes.type;
        if (tmpNodeData.IsPersonAccount) {
          imageFileName = 'Person' + imageFileName;
        }

        let nodeName = tmpNodeData.Name;
        let lastfirstName = [];
        if (tmpNodeData.LastName) {
          if (tmpNodeData.LastName) {
            lastfirstName.push(tmpNodeData.LastName);
          }
          if (tmpNodeData.FirstName) {
            lastfirstName.push(tmpNodeData.FirstName);
          }
          nodeName = lastfirstName.join(' ');
        } else if (tmpNodeData.LastName__c) {
          if (tmpNodeData.LastName__c) {
            lastfirstName.push(tmpNodeData.LastName__c);
          }
          if (tmpNodeData.FirstName__c) {
            lastfirstName.push(tmpNodeData.FirstName__c);
          }
          nodeName = lastfirstName.join(' ');
        }

        let AccountName;
        if (tmpNodeData.Account) {
          AccountName = tmpNodeData.Account.Name;
        } else if (tmpNodeData.Account__r) {
          AccountName = tmpNodeData.Account__r.Name;
        } else {
          AccountName = tmpNodeData.Company || tmpNodeData.Company__c || tmpNodeData.CompanyName || tmpNodeData.Name;
        }

        d3NodeData.push({
          Id: tmpNodeData.Id,
          root: tmpNodeData.Id === this.recordId,
          index: i,
          Name: nodeName || null,
          AccountId: tmpNodeData.AccountId || tmpNodeData.Account__c || tmpNodeData.Id,
          IsPersonAccount: tmpNodeData.IsPersonAccount || false,
          AccountName: AccountName || null,
          Website: tmpNodeData.Website || tmpNodeData.Website__c || null,
          Title: tmpNodeData.Title || tmpNodeData.Title__c || tmpNodeData.PersonTitle || null,
          Department: tmpNodeData.Department || tmpNodeData.Department__c || tmpNodeData.PersonDepartment || tmpNodeData.Site || null,
          Phone: tmpNodeData.Phone || tmpNodeData.Phone__c || null,
          Email: tmpNodeData.Email || tmpNodeData.Email__c || tmpNodeData.PersonEmail || null,
          LeadSource: tmpNodeData.LeadSource || tmpNodeData.LeadSource__c || null,
          image: `${relationMapResource}/images/${imageFileName}.png`,
          group: tmpNodeData.attributes.type || null,
          r: this._rSize
        });
      }
      d3Data.node = d3NodeData;

      for (let i = 0; i < originalLinkData.length; i++) {
        let tmpLinkData = originalLinkData[i];

        d3LinkData.push({
          Id: tmpLinkData.Id,
          index: i,
          relation: tmpLinkData.RelationType__c,
          source: tmpLinkData.From__c,
          target: tmpLinkData.To__c,
          arrow: tmpLinkData.Arrow__c || false,
          score: tmpLinkData.Score__c || 0,
          r: this._rSize,
          l: this._lineDistance
        });
      }
      d3Data.link = d3LinkData;

      this.recordData = d3Data;
    }).catch(error => {
      this.showToast('error', 'Error', 'データの取得でエラーが発生しました。 [ERROR_CODE-3]');
    });
  }

  get svgHeight() {
    return this.height;
  }

  get editBoxStyle() {
    return `max-height:${this.height}px`;
  }

  get containerStyle() {
    return `height:${this.height}px`;
  }

  /*****
   * Lightnig Pageで使用
   * 表示ターゲット（中心）となるrecordIdを取得
  *****/
  @wire(CurrentPageReference)
  setcurrentpagereference(currentPageReference) {
    this.currentPageReference = currentPageReference;

    if (this.currentPageReference.state && this.currentPageReference.state.c__recordId) {
      if (this.recordId != null && this.recordId !== this.currentPageReference.state.c__recordId) {
        this.recordId = this.currentPageReference.state.c__recordId;
        this.refreshContent();
      }
    }
  }

  /*****
   * Component Callback
  *****/
  connectedCallback() {
    this.isDesktop = document.body.classList.contains('desktop');
    this.parameters = this.getQueryParameters();

    if (this.currentPageReference.state && this.currentPageReference.state.c__recordId) {
      this.recordId = this.currentPageReference.state.c__recordId;
    }

    const ua = window.navigator.userAgent.toLowerCase();
    this.device = (() => {
      if (ua.indexOf('iphone') !== -1 || ua.indexOf('ipod') !== -1) return 'iphone';
      else if (ua.indexOf('ipad') !== -1) return 'ipad';
      else if (ua.indexOf('android') !== -1) return 'android';
      else if (ua.indexOf('windows') !== -1 && ua.indexOf('phone') !== -1) return 'windows_phone';
      else return 'desktop';
    })();
  }

  /*****
   * When Rendered Callback
  *****/
  renderedCallback() {
    if (this.d3Initialized) return;
    this.d3Initialized = true;

    if (this.parameters && this.parameters.c__recordId && this.parameters.c__recordId !== '') {
      this.recordId = this.parameters.c__recordId;
    }

    const componentRoot = this.tq('.c-relationMapComponent');
    componentRoot.classList.add(this.flexipageRegionWidth);
    componentRoot.classList.add(this.device);

    Promise.all([
      loadStyle(this, `${relationMapResource}/style.css`),
      loadScript(this, `${relationMapResource}/d3.v5.min.js`),
      this.getData()
    ]).then(() => {
      this.loaded = false;

      if (this.recordData != null && this.recordData !== undefined) {
        this.initializeD3(this.recordData);
      } else {
        this.showToast('error', 'Error', 'データの取得でエラーが発生しました。 [ERROR_CODE-1]');
      }
    }).catch(error => {
      console.error(error);
      this.showToast('error', 'Error', 'Error loading RelationMap Resource');
    });
  }

  /*****
   * D3 Refresh
  *****/
  refreshContent() {
    const svg = d3.select(this.tq('svg'));
    this.loaded = true;
    this.editTaregtId = null;
    this.fromSelectValue = null;
    this.toSelectValue = null;

    this.setViewField('From', '');
    this.setViewField('To', '');

    const inputFields = this.tqa('lightning-input-field');
    if (inputFields) {
      inputFields.forEach(field => {
        field.reset();
      });
    }

    svg
      .classed('init', false)
      .classed('animation', false)
      .selectAll('g')
      .remove();

    d3.selectAll(this.tqa('.infomation')).remove();
    d3.select(this.tq('.edit-area')).classed('area-open', false);

    Promise.all([
      this.getData()
    ]).then(() => {
      this.loaded = false;
      this.initializeD3(this.recordData);
    });
  }

  //Edit Relation Record
  editRelationRecord(target) {
    d3.selectAll(this.tqa('.infomation')).remove();
    this.editTaregtId = target;
    this.editFormArea.classed('area-open', true);
  }

  // Edit Action (Open)
  recordEditClick() {
    this.fromSelectValue = null;
    this.toSelectValue = null;
    this.setViewField('From', '');
    this.setViewField('To', '');

    return this.editRelationRecord();
  }

  // Edit Action (Close)
  editCloseClick() {
    this.editFormArea.classed('area-open', false);
  }

  // Reload Action
  contentsResetClick() {
    this.reloadContents();
  }

  //Reload Component
  reloadContents() {
    this.refreshContent();
  }

  // Zoom Event
  doZoom(changeScale, CurrentTransform) {
    this.setZoom(
      CurrentTransform.translateX,
      CurrentTransform.translateY,
      CurrentTransform.scaleX + changeScale,
      CurrentTransform.scaleY + changeScale
    );
  }

  zoomPlusClick() {
    this.doZoom(0.1, this.getTransformation(this.root.attr('transform')));
  }

  zoomMinusClick() {
    this.doZoom(-0.1, this.getTransformation(this.root.attr('transform')));
  }

  zoomResetClick() {
    this.resetZoom();
  }

  // convert transform to matrix
  getTransformation(transform) {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');

    g.setAttributeNS(null, 'transform', transform);
    let matrix = g.transform.baseVal.consolidate().matrix;
    let {a, b, c, d, e, f} = matrix; // var a=matrix.a, b=matrix.b, c=matrix.c, d=matrix.d, e=matrix.e, f=matrix.f; // ES5
    let scaleX, scaleY, skewX;
    if (scaleX = Math.sqrt(a * a + b * b)) a /= scaleX, b /= scaleX;
    if (skewX = a * c + b * d) c -= a * skewX, d -= b * skewX;
    if (scaleY = Math.sqrt(c * c + d * d)) c /= scaleY, d /= scaleY, skewX /= scaleY;
    if (a * d < b * c) a = -a, b = -b, skewX = -skewX, scaleX = -scaleX;
    return {
      translateX: e,
      translateY: f,
      rotate: Math.atan2(b, a) * 180 / Math.PI,
      skewX: Math.atan(skewX) * 180 / Math.PI,
      scaleX: scaleX,
      scaleY: scaleY
    };
  }


  //Set Zoom
  setZoom(x, y, sx, sy) {
    this.containerWidth = this.container.style('width').slice(0, -2) | 0;
    this.root.attr('transform', `translate(${x},${y}) scale(${sx},${sy})`);
  }

  //Reset Zoom
  resetZoom() {
    this.setZoom(
      this.resetZoomPosition.translateX,
      this.resetZoomPosition.translateY,
      this.resetZoomPosition.scaleX,
      this.resetZoomPosition.scaleY
    );
  }

  /*****
   * D3 Initialize
  *****/
  initializeD3(recordData) {
    /* Parameter Defined */
    const defaultSize = this._defaultSize;
    const chargeStrength = -300;
    const lineDistance = this._lineDistance;
    const lineDuplicationDistance = 5;
    const ArrowSize = 10;
    const rSize = {
      large: 60,
      small: this._rSize
    };
    const FONT_SETTING = {
      circleTitle: {
        defaultSize: this.nodeText || 16,
        size: this.nodeText || 16,
        line: 1.2
      },
      tooltipText: {
        defaultSize: this.tooltipText || 14,
        size: this.tooltipText || 14,
        line: 1.2
      }
    };
    let width = defaultSize;
    // Display4:3
    let height = parseInt(defaultSize * (defaultSize / 4 * 3 / 1000), 10);
    let InitActionComplete = false;

    /* Element Defined */
    let componentRoot;
    let controller;
    let svg;
    let colorScale;
    let link;
    let node;
    let tooltipNode;
    let simulation;
    let scoreController;
    let circle;
    let textNode;
    let imageNode;
    let tooltipPath;
    let tooltipText;

    /* Data Defined */
    let nodesData = recordData.node;
    let linksData = recordData.link;
    let relatonsStartTimer;
    let startSvgPan = false;

    /* Variable when InfomationBox dragable  */
    let boxHeight;
    let boxWidth;
    let infoBox;

    /* Function  */
    const doCircleMove = (d, target, action) => {
      const flag = (action === 'active');

      svg.selectAll('.selected').classed('selected', false);
      svg.selectAll('.conected').classed('conected', false);

      svg.selectAll('.node').classed('hide', flag);

      svg
        .selectAll('.line')
        .classed('linkSelected', false)
        .classed('hide', flag);

      d3.select(target).classed('selected', flag);

      if (!flag) {
        return false;
      }

      d3.select(target).classed('hide', !flag);

      svg
        .selectAll('.line')
        .filter(v => {
          if (d === v.source) {
            node.each(vj => {
              if (v.target === vj) {
                svg.select(`#node${vj.Id}`).classed('conected', flag);
                svg.select(`#node${vj.Id}`).classed('hide', !flag);
              }
            });
            return true;
          } else if (d === v.target) {
            node.each(vj => {
              if (v.source === vj) {
                svg.select(`#node${vj.Id}`).classed('conected', flag);
                svg.select(`#node${vj.Id}`).classed('hide', !flag);
              }
            });
            return true;
          }
        })
        .raise()
        .classed('linkSelected', flag)
        .classed('hide', !flag);
    }
    const infolinkMouseAction = (linkId, targetId, currentId, actioName) => {
      const active = (actioName === 'active');

      doCircleMove(null, this.root.select(`#node${targetId}`).node(), actioName);
      svg.selectAll('.line').classed('hide', active);
      this.root.select(`#${linkId}`)
        .raise()
        .classed('hide', false);
      this.root.select(`#node${currentId}`)
        .raise()
        .classed('selected', active);
    }

    const createPath = (width, height, offset, radius) => {
      const left = -width / 2;
      const right = width / 2;
      const top = -offset - height;
      const bottom = -offset;

      return `M 0,0
          L ${-offset},${bottom}
          H ${left + radius}
          Q ${left},${bottom} ${left},${bottom - radius}
          V ${top + radius}
          Q ${left},${top} ${left + radius},${top}
          H ${right - radius}
          Q ${right},${top} ${right},${top + radius}
          V ${bottom - radius}
          Q ${right},${bottom} ${right - radius},${bottom}
          H ${offset}
          L 0,0 z`;
    }

    /************
     * SETTINGS
     ************/
    componentRoot = d3.select(this.tq('.c-relationMapComponent'));
    controller = d3.select(this.tq('.controller'));
    scoreController = d3.select(this.tq('.score-controller'));
    this.container = d3.select(this.tq('.container'));
    this.containerInfo = d3.select(this.tq('.container-info'));
    this.editFormArea = d3.select(this.tq('.edit-area'));

    controller.classed('slds-hide', false);
    this.editFormArea.classed('slds-hide', false);


    /***********
     * INIT
     ************/
    svg = d3
      .select(this.tq('svg'))
      .attr('height', () => {
        let svgHeight = this._minSvgHeight;

        if (this.height && this.height > this._minSvgHeight) {
          svgHeight = this.height;
        }

        return svgHeight;
      })
      .attr('viewBox', `0, 0, ${width}, ${height}`);
    this.root = svg.append('g');
    this._svg = svg;
    try {
      colorScale = JSON.parse(this.colorSet.replace(/\'/g, '\''));
    } catch (e) {
      colorScale = d3.scaleOrdinal(d3.schemeSet2);
    }

    // Difine Line Marker
    const markerGroup = this.root.append('g').classed('marker-group', true);

    //Line and Arrow Color
    const arrowSet = {
      'arrowhead': '#ababab',
      'arrowhead-score0': this.score0 || '#ff0000',
      'arrowhead-score1': this.score1 || '#f41717',
      'arrowhead-score2': this.score2 || '#e63333',
      'arrowhead-score3': this.score3 || '#ababab',
      'arrowhead-score4': this.score4 || '#ababab',
      'arrowhead-score5': this.score5 || '#ababab',
      'arrowhead-score6': this.score6 || '#5ed752',
      'arrowhead-score7': this.score7 || '#47e437',
      'arrowhead-score8': this.score8 || '#31f21c',
      'arrowhead-score9': this.score9 || '#1aff00',
      'arrowhead-score10': this.score10 || '#1aff00',
      'arrowhead-active': '#ff6347'
    };

    for (let key in arrowSet) {
      if (key !== 'arrowhead') {
        markerGroup
          .append('defs')
          .append('marker')
          .attr('id', key)
          .classed('arrow', true)
          .attr('viewBox', `-0 -5 ${ArrowSize} ${ArrowSize}`)
          .attr('refX', rSize.small * 1.5 - rSize.small + ArrowSize + 2)
          .attr('refY', 0)
          .attr('orient', 'auto')
          .attr('markerWidth', 6)
          .attr('markerHeight', 6)
          .attr('xoverflow', 'visible')
          .append('svg:path')
          .attr('d', `M 0, -${ArrowSize / 2} L ${ArrowSize} , 0 L 0, ${ArrowSize / 2}`)
          .attr('fill', arrowSet[key]);
      } else {
        markerGroup
          .append('defs')
          .append('marker')
          .attr('id', key)
          .attr('fill', arrowSet[key]);
      }
    }

    link = this.root
      .append('g')
      .classed('link-group', true)
      .selectAll('.line')
      .data(linksData)
      .enter()
      .append('line')
      .attr('id', d => d.Id)
      .classed('line', true)
      .classed('score0', d => d.score <= 0)
      .classed('score1', d => d.score === 1)
      .classed('score2', d => d.score === 2)
      .classed('score3', d => d.score === 3)
      .classed('score4', d => d.score === 4)
      .classed('score5', d => d.score === 5)
      .classed('score6', d => d.score === 6)
      .classed('score7', d => d.score === 7)
      .classed('score8', d => d.score === 8)
      .classed('score9', d => d.score === 9)
      .classed('score10', d => d.score >= 10)
      .attr('stroke', d => arrowSet[`arrowhead-score${d.score}`])
      .classed('line-arrow', d => d.arrow)
      .classed('root', d => d.target === 0);

    // Create Node
    node = this.root
      .append('g')
      .classed('node-group', true)
      .selectAll('.node')
      .data(nodesData)
      .enter()
      .append('g')
      .attr('id', d => `node${d.Id}`)
      .classed('node', true);

    // Add Circle to Node
    circle = node
      .append('circle')
      .attr('id', d => `circle${d.Id}`)
      .classed('circle', true)
      .classed('root', d => d.root)
      .attr('r', d => d.r)
      .attr('fill', d => {
        const isFunction = typeof colorScale == 'function';
        let retunColor;

        if (isFunction) {
          retunColor = colorScale(d.group);
        } else {
          if (colorScale[d.group]) {
            retunColor = colorScale[d.group];
          } else {
            retunColor = colorScale['Custom'];
          }
        }

        return retunColor;
      });

    // Add Title Text to Node
    textNode = node
      .append('text')
      .classed('circle-title', true)
      .attr('dy', d => d.r + FONT_SETTING.circleTitle.size * FONT_SETTING.circleTitle.line)
      .attr('font-size', () => `${FONT_SETTING.circleTitle.size}px`)
      .text(d => d.Name);

    // Add Image to Node
    imageNode = node
      .append('image')
      .attr('xlink:href', d => {
        //Dummy Image
        let imagePath = 'images/dummy.png';

        if (typeof d.image !== 'undefined') {
          imagePath = d.image;
        }

        return imagePath;
      })
      .classed('circle-image', true)
      .attr('width', d => d.r * 1.5)
      .attr('height', d => d.r * 1.5)
      .attr('x', d => -((d.r / 4) * 3))
      .attr('y', d => -((d.r / 4) * 3));

    // Add Tooltip to Node
    tooltipNode = node
      .append('g')
      .classed('tooltip', true)
      .style('display', 'none');

    // Add Path to Tooltip
    tooltipPath = tooltipNode.append('path').classed('tooltip-path', true);

    // Add Text to Tooltip
    tooltipText = tooltipNode
      .append('text')
      .classed('tooltip-text', true)
      .text(d => d.Name)
      .attr('font-size', () => `${FONT_SETTING.tooltipText.size}px`);

    // forceSimulation Setting
    simulation = d3
      .forceSimulation()
      .velocityDecay(0.15) //摩擦力
      .alphaDecay(0.045)
      .force(
        'link',
        d3
          .forceLink()
          .id(d => d.Id)
          .iterations(16)
      )
      .force('collide', d3.forceCollide(lineDistance).iterations(16))
      .force('charge', d3.forceManyBody().strength(chargeStrength)) //反発力
      .force('center', d3.forceCenter(width / 2, height / 2)); //重力

    const start = () => {
      clearTimeout(relatonsStartTimer);

      // eslint-disable-next-line @lwc/lwc/no-async-operation
      relatonsStartTimer = setTimeout(() => {
        if (nodesData.length > 0 && linksData.length > 0) {
          svg.classed('init', true);

          //Called Create or Restart
          simulation
            .nodes(nodesData)
            .on('tick', () => {
              const lineDuplication = {};
              const posCheck = [];

              link
                .attr('x1', d => d.source.x)
                .attr('y1', d => d.source.y)
                .attr('x2', d => d.target.x)
                .attr('y2', d => d.target.y)
                .attr('transform', d => {
                  const redian = Math.atan2(
                    d.target.y - d.source.y,
                    d.target.x - d.source.x
                  );
                  const angle = redian * (180 / Math.PI);
                  const x = Math.cos(angle * (Math.PI / 180));
                  const y = Math.sin(angle * (Math.PI / 180));
                  const keys = [d.source.Id + d.target.Id, d.target.Id + d.source.Id];

                  keys.forEach((key) => {
                    lineDuplication[key] =
                      lineDuplication[key] == null || lineDuplication[key] === undefined
                        ? 0
                        : lineDuplication[key] + 1;
                  });

                  const target = (lineDuplication[keys[0]] + lineDuplication[keys[1]]) / 2;

                  const direction = target % 2 === 0
                    ? lineDuplicationDistance * (target - target / 2)
                    : -lineDuplicationDistance * (target - (target - 1) / 2);

                  let checkX = (direction * x).toFixed(5);
                  let checkY = (direction * y).toFixed(5);

                  if (posCheck.indexOf(`${checkX}:${checkY}`) === -1) {
                    posCheck.push(`${checkX}:${checkY}`);
                  } else {
                    checkX = checkX * -1;
                    checkY = checkY * -1;
                  }

                  return `translate(${-checkY},${checkX})`;
                });

              node
                .attr('cx', d => d.x)
                .attr('cy', d => d.y)
                .attr('transform', d => `translate(${d.x},${d.y})`);

              if (!InitActionComplete) {
                const rootNodes = node.filter(({root}) => root);
                let n0;

                //Root Nodeがあれば最初のNodeを取得
                //なければデータの最初のidから取得
                if (rootNodes._groups && rootNodes._groups[0]) {
                  n0 = d3.select(rootNodes._groups[0][0]);
                } else {
                  n0 = svg.select('#node' + nodesData[0].Id);
                }

                const nodeX = n0.attr('cx');
                const nodeY = n0.attr('cy');
                const centerDiffX = width / 2 - nodeX;
                const centerDiffY = height / 2 - nodeY;

                this.setZoom(centerDiffX, centerDiffY, 1, 1);

                return {k: 1, x: centerDiffX, y: centerDiffY};
              }
            })
            .on('end', () => {
              if (!InitActionComplete) {
                InitActionComplete = true;

                svg
                  .call(
                    d3
                      .drag()
                      .on('start', d => {
                        const currentTarget = d3.event.sourceEvent.target;

                        if (currentTarget === svg.node()) {
                          d3.event.sourceEvent.preventDefault();
                          startSvgPan = this.getTransformation(this.root.attr('transform'));
                          svg.classed('animation', false);
                          svg.classed('move', true);
                        }
                      })
                      .on('drag', d => {
                        if (startSvgPan !== false) {
                          startSvgPan.translateX += d3.event.sourceEvent.movementX || d3.event.dx * 2;
                          startSvgPan.translateY += d3.event.sourceEvent.movementY || d3.event.dy * 2;

                          this.setZoom(
                            startSvgPan.translateX,
                            startSvgPan.translateY,
                            startSvgPan.scaleX,
                            startSvgPan.scaleY
                          );
                        }
                      })
                      .on('end', d => {
                        if (startSvgPan !== false) {
                          startSvgPan = false;
                          svg.classed('animation', true);
                          svg.classed('move', false);
                        }
                      })
                  )
                  .on('click', d => {
                    const currentTarget = d3.event.sourceEvent.target;

                    if (currentTarget === svg.node()) {
                      svg.selectAll(this.tqa('.infomation')).remove();
                    }
                  });

                node
                  .call(
                    d3
                      .drag()
                      .on('start', d => {
                        const currentTarget = d3.event.sourceEvent.target.closest('.node') || d3.event.sourceEvent.target;

                        if (!d3.event.active) {
                          simulation.alphaTarget(1).restart();
                        }

                        d.fx = d.x;
                        d.fy = d.y;
                        doCircleMove(d, currentTarget, 'active');
                      })
                      .on('drag', d => {
                        d.fx = d3.event.x;
                        d.fy = d3.event.y;
                      })
                      .on('end', d => {
                        const currentTarget = d3.event.sourceEvent.target.closest('.node') || d3.event.sourceEvent.target;

                        if (!d3.event.active) simulation.alphaTarget(0);
                        doCircleMove(d, currentTarget, 'inactive');
                      })
                  )
                  .on('click', d => {
                    const currentTarget = d3.event.target;

                    //Delete Deplicate Node
                    d3.select(this.tq(`#info${d.Id}`)).remove();

                    // Create Infomation Box
                    const elementScale =
                      d3
                        .select(currentTarget)
                        .attr('r') * 2;
                    const infomation = this.containerInfo
                      .append('div')
                      .attr('id', `info${d.Id}`)
                      .classed('infomation', true);

                    const dl = infomation.append('dl');
                    const dt = dl.append('dt');
                    dt.call(
                      d3
                        .drag()
                        .on('start', d => {
                          dt.classed('active', true);

                          infoBox = d3.select(dt.node().parentNode.parentNode);

                          let pan = this.getTransformation(dt.node().parentNode.parentNode.style.transform.replace(/px/g, ''));
                          infoBox.attr('data-dx', pan.translateX);
                          infoBox.attr('data-dy', pan.translateY);

                          this.containerHeight = this.container.style('height').slice(0, -2) | 0;
                          this.containerWidth = this.container.style('width').slice(0, -2) | 0;
                          boxHeight = infoBox.style('height').slice(0, -2) | 0;
                          boxWidth = infoBox.style('width').slice(0, -2) | 0;
                        })
                        .on('drag', d => {
                          let x = parseInt(infoBox.attr('data-dx'), 10) + (d3.event.sourceEvent.movementX || d3.event.dx);
                          let y = parseInt(infoBox.attr('data-dy'), 10) + (d3.event.sourceEvent.movementY || d3.event.dy);

                          //Adjust position X
                          if (x <= 0 || this.containerWidth < boxWidth + x) {
                            x = parseInt(infoBox.attr('data-oldx'), 10) || parseInt(infoBox.attr('data-dx'), 10);
                          }

                          //Adjust position Y
                          if (y <= 0 || this.containerHeight < boxHeight + y) {
                            y = parseInt(infoBox.attr('data-oldy'), 10) || parseInt(infoBox.attr('data-dy'), 10);
                          }

                          infoBox
                            .attr('data-dx', x)
                            .attr('data-dy', y)
                            .attr('data-oldx', x)
                            .attr('data-oldy', y)
                            .style('transform', () => `translate(${x}px,${y}px)`);
                        })
                        .on('end', d => {
                          dt.classed('active', false);
                          infoBox
                            .attr('data-x', infoBox.attr('data-oldx'))
                            .attr('data-y', infoBox.attr('data-oldy'));
                        })
                    );

                    const dd = dl.append('dd');

                    dt.append('span').text(d.Name);

                    const closeButton = infomation
                      .append('span')
                      .classed('close-buttton', true)
                      .on('click', () => infomation.remove())
                      .append('svg')
                      .attr('width', '100%')
                      .attr('height', '100%')
                      .attr('viewBox', '0, 0, 512, 512')
                      .append('g')
                      .append('path')
                      .attr(
                        'd',
                        'M437.5,386.6L306.9,256l130.6-130.6c14.1-14.1,14.1-36.8,0-50.9c-14.1-14.1-36.8-14.1-50.9,0L256,205.1L125.4,74.5 c-14.1-14.1-36.8-14.1-50.9,0c-14.1,14.1-14.1,36.8,0,50.9L205.1,256L74.5,386.6c-14.1,14.1-14.1,36.8,0,50.9 c14.1,14.1,36.8,14.1,50.9,0L256,306.9l130.6,130.6c14.1,14.1,36.8,14.1,50.9,0C451.5,423.4,451.5,400.6,437.5,386.6z'
                      );

                    // Add Contents
                    const contentsDiv = dd
                      .append('div')
                      .classed('infomation-inner', true);

                    // Action assigned if Browser is Touch Device
                    if (!componentRoot.classed('desktop')) {
                      contentsDiv
                        .call(
                          d3
                            .drag()
                            .on('start', d => {
                              const currentTarget = contentsDiv.node();
                              currentTarget.classList.add('notAnimation');

                              if (!currentTarget.style.marginTop) {
                                currentTarget.style.marginTop = 0;
                              }
                            })
                            .on('drag', d => {
                              const currentTarget = contentsDiv.node();

                              let y = d3.event.sourceEvent.movementY || d3.event.dy;
                              let m = parseInt(currentTarget.style.marginTop, 10);

                              currentTarget.style.marginTop = `${m + y}px`;
                            })
                            .on('end', d => {
                              const currentTarget = contentsDiv.node();
                              currentTarget.classList.remove('notAnimation');

                              let m = parseInt(currentTarget.style.marginTop, 10);
                              let dl = currentTarget.childNodes[0];
                              let parentDd = currentTarget.parentNode;
                              let dlHeight = parseInt(dl.clientHeight || dl.offsetHeight, 10);
                              let ddHeight = parseInt(parentDd.clientHeight || parentDd.offsetHeight, 10);
                              let limitHeight = dlHeight - ddHeight;

                              if (m > 0) {
                                currentTarget.style.marginTop = 0;
                              } else if (Math.abs(m) > limitHeight) {
                                if (dlHeight > ddHeight) {
                                  currentTarget.style.marginTop = `${-limitHeight}px`;
                                } else {
                                  currentTarget.style.marginTop = 0;
                                }
                              }
                            })
                        );
                    }

                    const contentsDl = contentsDiv
                      .append('dl');

                    let AccountType = d.group;
                    if (d.IsPersonAccount) {
                      AccountType += ' (個人取引先)';
                    }
                    contentsDl.append('dt').text('ID');
                    contentsDl.append('dd').text(d.Id);
                    contentsDl.append('dt').text('NAME');
                    contentsDl.append('dd').html(`<a href="/${d.Id}" target="_blank">${d.Name}</a>`);
                    contentsDl.append('dt').text('OBJECT');
                    contentsDl.append('dd').text(AccountType);
                    if (d.AccountId) {
                      contentsDl.append('dt').text('ACCOUNT');
                      contentsDl.append('dd').html(`<a href="/${d.AccountId}" target="_blank">${d.AccountName}</a>`);
                    }
                    if (d.Title) {
                      contentsDl.append('dt').text('TITLE');
                      contentsDl.append('dd').text(d.Title);
                    }
                    if (d.Department) {
                      contentsDl.append('dt').text('DEPARTMENT');
                      contentsDl.append('dd').text(d.Department);
                    }
                    if (d.Email) {
                      contentsDl.append('dt').text('EMAIL');
                      contentsDl.append('dd').text(d.Email);
                    }
                    if (d.Phone) {
                      contentsDl.append('dt').text('PHONE');
                      contentsDl.append('dd').text(d.Phone);

                    }
                    if (d.LeadSource) {
                      contentsDl.append('dt').text('LEADSOURCE');
                      contentsDl.append('dd').text(d.LeadSource);
                    }
                    if (d.Website) {
                      contentsDl.append('dt').text('WEBSITE');
                      contentsDl
                        .append('dd')
                        .html(`<a href="/${d.Website}" target="_blank">${d.Website}</a>`);
                    }
                    contentsDl.append('dt').text('RELATION');
                    const ddNode = contentsDl.append('dd');
                    linksData.forEach(({Id, target, source, relation}) => {
                      if (target.Id === d.Id || source.Id === d.Id) {
                        let dText = 'To: ';
                        let dLink = target.Id;
                        let dName = target.Name;

                        if (dLink == d.Id) {
                          dText = 'From: ';
                          dLink = source.Id;
                          dName = source.Name;
                        }

                        const linksDataP = ddNode.append('p');
                        linksDataP.append('span').text(dText);
                        const linksDataA = linksDataP
                          .append('a')
                          .attr('href', `/${dLink}`)
                          .attr('target', '_blank')
                          .on('click', () => {
                            if (!this.root.select(`#${Id}`).classed('hide') && this.root.select(`#node${dLink}`).classed('selected')) {
                              return true;
                            }
                            d3.event.preventDefault();
                            infolinkMouseAction(Id, dLink, d.Id, 'active');
                          });

                        //Action assigned if Browser is desktop
                        if (componentRoot.classed('desktop')) {
                          linksDataA
                            .on('mouseover', () => {
                              infolinkMouseAction(Id, dLink, d.Id, 'active');
                            })
                            .on('mouseout', () => {
                              infolinkMouseAction(Id, dLink, d.Id, 'inactive');
                            });
                        }

                        linksDataA.append('span').text(dName);
                        linksDataP.append('br');
                        linksDataP.append('span').text(`Relation: ${relation}`);

                        const actionP = ddNode
                          .append('p')
                          .classed('button-edit', true);
                        actionP
                          .append('span')
                          .text('Edit')
                          .on('click', () => {
                            this.editRelationRecord(Id);
                          });
                        actionP
                          .append('span')
                          .text('Delete')
                          .on('click', () => {
                            this.editTaregtId = null;

                            if (window.confirm('Relationを削除します。よろしいでしょうか？')) {
                              deleteRecord(Id)
                                .then(() => {
                                  this.showToast('success', 'Success', 'Relationを削除しました。');
                                  this.reloadContents();
                                }).catch(error => {
                                  this.showToast('error', 'Error', error.body.message);
                                });
                            }
                          });
                      }
                    });

                    // adjust box position
                    this.containerHeight = this.container.style('height').slice(0, -2) | 0;
                    this.containerWidth = this.container.style('width').slice(0, -2) | 0;
                    boxHeight = infomation.style('height').slice(0, -2) | 0;
                    boxWidth = infomation.style('width').slice(0, -2) | 0;
                    let leftMargin = 30;
                    let topMargin = -(boxHeight - elementScale / 2) / 2;
                    let elementBottom = topMargin + d3.event.offsetY + boxHeight;
                    let elementRight = leftMargin + d3.event.offsetX + boxWidth;

                    if (this.containerHeight < elementBottom + 30) {
                      topMargin = topMargin + (this.containerHeight - elementBottom);
                    }

                    if (d3.event.offsetY + topMargin < 0) {
                      topMargin = 0;
                    }

                    if (this.containerWidth < elementRight + 30) {
                      leftMargin = -(boxWidth + elementScale);
                    }

                    if (componentRoot.classed('SMALL')) {
                      const smallX = (this.containerWidth - boxWidth) / 2;
                      const smallY = (this.containerHeight - boxHeight) / 2;
                      infomation
                        .attr('data-x', smallX)
                        .attr('data-y', smallY)
                        .style('transform', () => `translate(${smallX}px,${smallY}px)`);
                    } else {
                      infomation
                        .attr('data-x', d3.event.offsetX + leftMargin)
                        .attr('data-y', d3.event.offsetY + topMargin)
                        .style('transform', () => `translate(${d3.event.offsetX + leftMargin}px,${d3.event.offsetY + topMargin}px`);
                    }

                  })
                  .on('mouseover', () => {
                    const currentTarget = d3.event.target.closest('.node') || d3.event.target;
                    const node = d3.select(currentTarget);
                    const tooltip = node.select('.tooltip');
                    const tooltipCircle = node.select('.circle');
                    const tooltipPath = node.select('.tooltip-path');
                    const tooltipText = node.select('.tooltip-text');
                    let tooltipPaddingX = 20;
                    let tooltipPaddingY = 20;
                    let tooltipPathOffset = 10;
                    let tooltipPathRadius = 5;
                    let tooltipScale;

                    // Adjust Tooltip Size
                    const transformParam = this.getTransformation(this.root.attr('transform'));
                    const viewScale = (height - parseInt(this.container.style('width').slice(0, -2), 10)) > 0
                      ? height / parseInt(this.container.style('width').slice(0, -2), 10)
                      : 1.1;
                    tooltipScale = 1 / transformParam.scaleX * viewScale;

                    FONT_SETTING.tooltipText.size = FONT_SETTING.tooltipText.defaultSize * tooltipScale;
                    tooltipPaddingX = tooltipPaddingX * tooltipScale;
                    tooltipPaddingY = tooltipPaddingY * tooltipScale;
                    tooltipPathOffset = tooltipPathOffset * tooltipScale;
                    tooltipPathRadius = tooltipPathRadius * tooltipScale;

                    // Taregt Node move to Front
                    node.raise();

                    tooltip.style('display', 'block').attr('transform', () => `translate(0,${-tooltipCircle.attr('r')})`);

                    tooltipText.attr('font-size', () => `${FONT_SETTING.tooltipText.size}px`);

                    const textBox = tooltipText.node().getBBox();
                    tooltipText.attr(
                      'dy',
                      -(tooltipPaddingY / 2 + textBox.height - tooltipPathOffset / 4 - tooltipPathRadius / 2)
                    );

                    tooltipPath.attr(
                      'd',
                      createPath(
                        textBox.width + tooltipPaddingY,
                        textBox.height + tooltipPaddingX,
                        tooltipPathOffset,
                        tooltipPathRadius
                      )
                    );
                  })
                  .on('mouseout', () => {
                    const currentTarget = d3.event.target.closest('.node') || d3.event.target;
                    const node = d3.select(currentTarget);
                    const tooltip = node.select('.tooltip');

                    tooltip.style('display', 'none');
                  });

                simulation
                  .velocityDecay(1)
                  .alphaDecay(1)
                  .force('charge', d3.forceManyBody().strength(0))
                  .stop();

                this.resetZoomPosition = this.getTransformation(this.root.attr('transform'));

                svg.classed('animation', true);
              }
            });

          try {
            simulation
              .force('link')
              .links(linksData)
              .id(d => d.Id);
          } catch (e) {
            console.error(e);
            this.showToast('error', 'Error', 'データの設定でエラーが発生しました。');
          }
        } else {
          start();
        }
      }, 200);
    }

    start();
  }
}