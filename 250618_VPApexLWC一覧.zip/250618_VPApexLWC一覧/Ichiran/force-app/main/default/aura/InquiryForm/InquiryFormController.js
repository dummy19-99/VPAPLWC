({
    // タイトルの設定
    getPageTitle : function(component, event, helper) {
        return 'お問合せ';
    },
    
    // ページ説明の設定
    getPageDescription : function(component, event, helper) {
        return 'お問合せ内容および、ご連絡先をご入力いただき、\n「個人情報の取り扱いについて」にご同意の上、\n「同意して確認画面へ進む」ボタンを押してください。';
    },
    Init : function(component, event, helper) {
        
        var inquiryInput = component.get("v.inquiryInput");

        if(!inquiryInput ||inquiryInput.length === 0){
            helper.initLead(component, event, helper);
        }else{
            helper.setTypeCheck(component, event, helper);
            helper.setInquiryCheck(component, event, helper);
        }
    },

    
    // お問合せ種別入力チェック
    onTypeCheck : function(component, event, helper) {
        const selected = event.getSource().get("v.label");
        component.set("v.inquiryInput.InquiryType__c", selected);
        
        helper.setTypeCheck(component, event, helper);
	},
    
     // お問合せ入力チェック   
    onInquiryCheck : function(component, event, helper) {        
        helper.setInquiryCheck(component, event, helper);
	},
    
     // 詳細はこちら押下時処理      
    showDetailMsg : function(component, event, helper){
        
        var detailAddres= document.getElementById("detailAddressSettingMsg");
        
        if (detailAddres.style.display === "block") {
            detailAddres.style.display = "none";
        } else {
            detailAddres.style.display = "block";
        }     
    },
    
    // 同意して確認画面へ進むボタン押下時処理
    next : function (component, event, helper) {
        const checkAll=[helper.setTypeCheck(component, event, helper),
                        helper.setInquiryCheck(component, event, helper)];

        helper.next(component, event, helper, checkAll);
            
    } 
})