({
    
    
    //問い合わせ種別入力チェック
    setTypeCheck : function(component, event, helper){
        const fieldValue = component.get("v.inquiryInput.InquiryType__c");
        return helper.requiredCheck(component, fieldValue, "v.inquiryTypeInputCheckViewMap", '「お問合せ種別」は必須です。');
    },
    
    //問い合わせ内容入力チェック
    setInquiryCheck : function(component, event, helper){
        const fieldValue = component.get("v.inquiryInput.InquiryContents__c");
        return helper.requiredCheck(component, fieldValue, "v.inquiryInputCheckViewMap", '「お問合せ」は必須です。');
    },
})