({
	getRelatedListForEdit : function(cmp, evt, helper){
		// ステータスの選択リスト値とラベル名取得
		var action1 = cmp.get("c.getPickListInfo");
		var params = {
				"objectName": cmp.get('v.objectAPI'),
				"strField": 'Status__c',
				"delItemStr": cmp.get('v.statusNonDispItem'),
		};
		
		action1.setParams(params);
		action1.setCallback(this, function(an) {
			var state = an.getState();
			if (state === "SUCCESS") {
				var returnValue=an.getReturnValue();
				//　ラベル名、オプション設定
				cmp.set("v.labelName", returnValue.lstObjectFields[0].fieldName);
				cmp.set("v.selectOptions", returnValue.lstObjectFields[0].picklistOptions);
			}
		});
		// enqueue the action 
		$A.enqueueAction(action1);

		
		// 追加項目のヘルプテキスト取得
		var action2 = cmp.get("c.getHelpText");
		var params = {
				"objectName": cmp.get('v.objectAPI'),
				"strField": 'AddSearchItem__c'
		};
		
		action2.setParams(params);
		action2.setCallback(this, function(an) {
			var state = an.getState();
			if (state === "SUCCESS") {
				var returnValue=an.getReturnValue();
				//　ラベル名、オプション設定
				cmp.set("v.searchItemHelpText", returnValue.lstObjectFields[0].helpText);
			}
		});
		// enqueue the action 
		$A.enqueueAction(action2);
	}
})