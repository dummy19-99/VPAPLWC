({
	// 初期処理
	doInit : function(cmp, evt, helper) {
		helper.getRelatedListForEdit(cmp, evt, helper);
	},
	//「検索」ボタン押下時、親コンポーネントの検索処理呼び出しイベント
    handleSearchEvent : function(cmp, evt, helper) {
		var ev = cmp.getEvent("tc_searchEvent");
		var inputAddSearchItemVal = '';
		if (cmp.find('inputAddSearchItem') != undefined) {
			inputAddSearchItemVal = cmp.find('inputAddSearchItem').get('v.value');
		}
		// イベントにパラーメータ設定
		ev.setParams({
			"statusVal":cmp.find('inputStatus').get('v.value'),
			"dateVal":cmp.find('inputDate').get('v.value'),
			"addItemVal":inputAddSearchItemVal
		});
		//　イベント発火
		ev.fire();
	},
	//「クリア」ボタン押下時、親コンポーネントの検索処理呼び出しイベント
    handleClearSearchEvent : function(cmp, evt, helper) {
		var ev = cmp.getEvent("tc_clearSearchEvent");
		//　イベント発火
		ev.fire();
		// 選択項目値クリア
		cmp.find('inputStatus').set('v.value', ''); 
		cmp.find('inputDate').set('v.value', null);
		cmp.find('inputAddSearchItem').set('v.value', '');
	}
})