({
    /* 20190516 不具合対応 goto
     * 共通コンポーネントに処理を移動する
	updateInquiryCheckList : function(cmp, event, helper) {
        var cmpEvent = cmp.getEvent("updateInquiryCheckbox");
        var source = event.getSource();
        var name = source.get("v.name");
        var checked = source.get("v.checked"); 
        
        cmpEvent.setParams({
            "whereSOQLString" : name + "_" + checked});
        cmpEvent.fire();
    },*/
    
    showDetailPage : function(cmp, event, helper) {
       
        var articles = cmp.get('v.articles');
        
        if(!!articles && articles.length > 0){
            // 選択されたリストのインデックスを取得する
            var index = event.target.id;
            if(!!index){
                helper.showDetailCommonPage(cmp, event, helper, articles[index]); 
            }
        }
    },
})