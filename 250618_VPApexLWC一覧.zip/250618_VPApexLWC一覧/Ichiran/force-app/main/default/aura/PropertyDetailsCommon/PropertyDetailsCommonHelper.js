({
    // 物件情報取得
	getArticleInfo : function(component, event) {
        
        // ArticleID
        var recordId = component.get("v.recordId");
        
        // Apex
        var action = component.get("c.getArticleInfo");

        action.setParams({
            "articleId": recordId
        });
        action.setCallback(this, function(data) {
            
            var rslt = data.getState();
            
            if (rslt === "SUCCESS"){
                component.set("v.property", data.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
        
    // 対象クラスがページに表示されているかチェックする
    // True : 一つでも表示されている
    // False: 一つも表示されていない
    classDispCheck : function(className){
        
        var result = false;
        
        let target = document.getElementsByClassName(className);
        
        for (var i = 0; i < target.length; i++) {
            // スクロールバーを含んでいない高さ
            let t_height = target[i].clientHeight;
            
            // クラスの表示位置
            let offsetY = target[i].getBoundingClientRect().top
            
            // スクロールバーを含んでいないウインドウの高さ
            let screenHeight = document.documentElement.clientHeight;
            
            // クラスまでの距離を取得
            let t_position = offsetY - screenHeight;
            
            if(-screenHeight<=(t_position + t_height) && t_position  < 0) { 
                result = true;
            }
        }
        return result;
    },
    
    // クエリ文字列を取得する
    // 画面遷移時のパラメータを取得する
    getUrlParameter : function(sParam) {
        
        var sPageURL = decodeURIComponent(window.location.search.substring(1)),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : sParameterName[1];
            }
        }
    },
})