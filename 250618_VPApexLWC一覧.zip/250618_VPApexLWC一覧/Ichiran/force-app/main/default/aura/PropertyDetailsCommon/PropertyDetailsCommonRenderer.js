({
    afterRender : function( component, helper ) {

        this.superAfterRender();

        var didScroll = false;

        window.onscroll = function() {
            didScroll = true;
        };

        var idOfSetInterval = window.setInterval( $A.getCallback( function() {
                        
            if ( didScroll && component.isValid() ) {
                
                didScroll = false;
                
                var hideModal = helper.classDispCheck('hide-modal');   
                
                var dispTarget = helper.classDispCheck('esws__inquiry_buttons__row');     
                
                var cmpTarget = component.find('esws_property_floating_menu');
                
                if(hideModal){
                    if(dispTarget){
                        $A.util.removeClass(cmpTarget, 'disp_esws__floating_menu'); 
                    }else{
                        $A.util.addClass(cmpTarget, 'disp_esws__floating_menu');
                    } 
                }
            }
            
        }), 50 );

        // インターバルをセットする
        component.set( "v.setIntervalId", idOfSetInterval );
        
        
        
    },

    unrender: function( component, helper ) {

        this.superUnrender();
        // インターバルを作成する
        window.clearInterval( component.get( "v.setIntervalId" ) );
    }
})