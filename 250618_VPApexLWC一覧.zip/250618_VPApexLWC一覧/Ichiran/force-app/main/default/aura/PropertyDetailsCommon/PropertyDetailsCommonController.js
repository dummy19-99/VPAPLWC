({
	Init : function(component, event, helper) {
        
        component.set("v.recordId", helper.getUrlParameter("propertyId"));
        
        var stringState = helper.getUrlParameter("withThumbnail");
        
        component.set("v.withThumbnail", stringState === 'true' ? true : false);
        
        // 物件の初期値取得
        helper.getArticleInfo(component, event, helper);
	},

    download : function (component,event,helper) {
        component.getConcreteComponent().download();
    },
    
   //　お問い合わせ
   goToInquiryForm　: function (component, event, helper) {
        // ArticleID
        var articleId  = new Array();
        
        articleId.push(component.get("v.recordId"));
        
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/s"));
        
        window.open(baseURL + '/s/propertyinquiryformdisplay?propertyIds=' + articleId, "_blank");
    },
    
    // 見学予約
    goToVisitBookingInquiryForm　: function (component, event, helper) {
        // ArticleID
        var articleId  = new Array();
        
        articleId.push(component.get("v.recordId"));
        
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/s"));

        window.open(baseURL + '/s/propertyinquiryformdisplay?propertyIds=' + articleId + '&' + 'visitBooking=true', "_blank");
    },
    
    // スライダーからのイベント
    sliderZoom : function(component, event) {
        
        var cmpTarget = component.find('esws_property_floating_menu');
        $A.util.removeClass(cmpTarget, 'disp_esws__floating_menu'); 
    },
    
    // 周辺地図押下時
    onMapAround  : function(component, event) {
        
        //緯度情報
        var location_Latitude = component.get('v.property.Location__Latitude__s');
        //経度情報
        var location_Longitude = component.get('v.property.Location__Longitude__s');
        //住所
        var propertyLocation =  component.get('v.property.PropertyLocation__c');
        //地図表示情報
        var mapInfo = (location_Latitude && location_Longitude) ? location_Latitude + ',' + location_Longitude : propertyLocation;
        //20200619 IEでのGoogleMap文字化け対応
        var mapInfoencode = encodeURI(mapInfo);
        if(!!mapInfo){
            //window.open('https://maps.google.co.jp/maps?q=' + mapInfo , "_blank");
            window.open('https://maps.google.co.jp/maps?q=' + mapInfoencode  , "_blank");
        }   
    }

})