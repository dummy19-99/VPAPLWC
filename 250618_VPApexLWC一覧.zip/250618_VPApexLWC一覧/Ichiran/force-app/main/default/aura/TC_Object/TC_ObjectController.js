({	
    //初期表示
    doInit : function(cmp, evt, helper){
        helper.initDo(cmp,evt);
        var dispSalesFlg = cmp.get("v.dispSalesFlg");//売上分配率制御フラグ
        var dispPlansFlg = cmp.get("v.dispPlansFlg");//予定情報制御フラグ
        if(dispSalesFlg){
            if(dispPlansFlg){
                cmp.set("v.styleSize","1400");
            } else {
                cmp.set("v.styleSize","1200");
            }
        } else {
            if(dispPlansFlg){
                cmp.set("v.styleSize","1300");
            } else {
                cmp.set("v.styleSize","1100");
            }
        }
    },
    //テンプレート選択
    dispTemplate : function(cmp, evt, helper){
        helper.tempDisplay(cmp, evt);
    },
    //テンプレート更新
    createTask : function(cmp, evt, helper){
        //項目検査結果クリア
        cmp.set("v.validList",[]);
        var userFilled = true;
        //validを求めるevent
        var validEvent = $A.get("e.c:validEvent");
        validEvent.fire();
        //売上分配率制御フラグ
        var dispSalesFlg = cmp.get("v.dispSalesFlg");
        //メッセージ
        var errorMsg = [];

        var validList = cmp.get("v.validList");
        //項目の妥当性にfalseがない場合
        if(!validList.includes(false)){

            var taskMasterList = cmp.get("v.taskMasterList");

            //売上分配率整合性チェック用
            var totalMainRate = 0;//totalMainRate
            var totalSubRate = 0;//totalsubRate
            var subExistFlg = false;//subExistFlg
            var mainName = "";//メインタスク名

            for(var tm of taskMasterList){
                //売上分配率制御フラグがtrue
                if(dispSalesFlg){
                    //売上分配率整合性チェック
                    //現タスクメイン判定フラグ
                    if(tm.RecordType.Name === 'Main'){
                        
                        if(subExistFlg && (totalMainRate > 0 || totalSubRate > 0)){
                            //subが100%でない場合、
                            if(totalSubRate != 100){
                                //メッセージセット
                                var errMsgStr = $A.get("$Label.c.TC_ErrorMsg_TotalSubRate100");
                                errorMsg.push(errMsgStr.replace("mainName",mainName));
                            }
                        }
                        
                        if(tm.SalesDistributionRate__c != undefined){
                            //メインの売上分配率(%)を合算
                            totalMainRate = totalMainRate + Number(tm.SalesDistributionRate__c);
                        }
        
                        totalSubRate = 0; //サブ売上分配率(%)初期化
                        subExistFlg = false; //サブありフラグ初期化
                        mainName = tm.Name;//メイン名設定（エラーメッセージ用）
                    } else {

                        //subあり
                        subExistFlg = true;
        
                        if(tm.SalesDistributionRate__c != undefined){
                            //サブの売上分配率(%)を合算
                            totalSubRate = totalSubRate + Number(tm.SalesDistributionRate__c);
                        }
                    }
                }

                //担当者有無チェック
                //非カテゴリタスク場合
                if(!tm.CategoryKbn__c){
                    //行追加の場合user__cを持ってない
                    if(tm.user__c == undefined){
                        //項目が入力されなかったら
                        //入力してない || 入力して削除
                        if(tm.user__r == undefined || tm.user__r.Id == undefined){
                            userFilled = false;
                            continue;
                        }
                    } else {
                        if(tm.user__r.Id == undefined){
                            //項目が入力されなかったら
                            userFilled = false;
                            break;
                        } 
                    }
                    tm.user__c = tm.user__r.Id;
                } else {
                    //非カテゴリの場合、担当者クリア
                    tm.user__c = null; 
                }
            }
            //売上分配率制御フラグがtrue
            if(dispSalesFlg){
                //subが100%でない場合、
                if(subExistFlg == true && totalSubRate != 100){
                    //メッセージセット
                    var errMsgStr = $A.get("$Label.c.TC_ErrorMsg_TotalSubRate100");
                    errorMsg.push(errMsgStr.replace("mainName",mainName));
                }
                //メインが100%でない場合、
                if(totalMainRate > 0 && totalMainRate != 100){
                    //メッセージセット
                    errorMsg.push($A.get("$Label.c.TC_ErrorMsg_TotalMainRate100"));
                }
            }
            if(userFilled && errorMsg.length === 0){
                //エラーなしの場合
                var delList = cmp.get("v.delList");
                helper.createTask(cmp, evt,taskMasterList,delList);
            }else{

                if(!userFilled){
                    //担当者のエラーメッセージを先頭に追加
                    errorMsg.unshift("担当者を入力してください。")
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Error!",
                    message: "" + errorMsg,//「""」ないとメッセージ表示されないため、「""」追加
                    type: "error"
                });
                toastEvent.fire();
            }
        }else{
            var taostEvent = $A.get("e.force:showToast");
            taostEvent.setParams({
                title: "Error!",
                message: "入力に誤りがあります。確認してください。",
                type: "error"                
            });
            taostEvent.fire();
        }
    },
    //タスク追加
    addItem: function(cmp, evt, helper) {
        var cTaskObjectAPI = cmp.get("v.cTaskObjectAPI");
        var mainTaskRecordTypeId = cmp.get("v.mainTaskRecordTypeId");
        var data = cmp.get("v.taskMasterList");
        var newData = [];
        var mainTaskChecked = false;
        var cnt = 0;
        //リスト作り直し作業
        for(var d of data){
            cnt++;
            //Mainタスクの場合
            if(d.RecordType.Name === 'Main'){
                //追加することがあれば
                if(mainTaskChecked){
                    //追加する行（空行）
                    var newRow = {"sobjectType": cTaskObjectAPI,
                                  "RecordTypeId":mainTaskRecordTypeId,
                                  "CategoryKbn":false,
                                  "RecordType":{"Name":"Main",
                                                "Id":mainTaskRecordTypeId},
                                  "selectedFlg__c":false};
                    //空行を追加
                    newData.push(newRow);
                    //追加することないよ
                    mainTaskChecked = false;
                }
                //選択された場合
                if(d.selectedFlg__c){
                    //追加することがあるよ
                    mainTaskChecked = true;
                }
            }
            
            //現在の行を追加
            newData.push(d);
            
            //最後の場合その後ろに空行を追加
            if(mainTaskChecked && data.length === cnt){
                //追加する行（空行）
                var newRow = {"sobjectType": cTaskObjectAPI,
                              "RecordTypeId":mainTaskRecordTypeId,
                              "CategoryKbn":false,
                              "RecordType":{"Name":"Main",
                                            "Id":mainTaskRecordTypeId},
                              "selectedFlg__c":false};
                //空行を前に追加
                newData.push(newRow);
            }
        }
        cmp.set("v.taskMasterList",newData);
    },
    //サブタスク追加
    addSubItem: function(cmp, evt, helper) {
        var cTaskObjectAPI = cmp.get("v.cTaskObjectAPI");
        var subTaskRecordTypeId = cmp.get("v.subTaskRecordTypeId");
        var data = cmp.get('v.taskMasterList');
        var newData = [];
        var newRowMain = [];

        //リスト作り直し作業
        for(var d of data){
            newData.push(d);
            if(d.selectedFlg__c){
                if(d.RecordType.Name === 'Main') {
                    //メインの場合
                    newRowMain = {"Id":d.Id,
                                    "sobjectType": d.sobjectType,
                                    "RecordTypeId":d.RecordTypeId,
                                    "Name":d.Name,
                                    "text1__c":d.text1__c,
                                    "Status__c":d.Status__c,
                                    "date__c":d.date__c,
                                    "DisplayNum__c":d.DisplayNum__c,
                                    "SalesDistributionRate__c":d.SalesDistributionRate__c,
                                    "SalesAmount__c":d.SalesAmount__c,
                                    "CategoryKbn__c":true,
                                    "RecordType":{"Name":"Main",
                                                "Id":d.RecordTypeId},
                                    "selectedFlg__c":d.selectedFlg__c};

                    newData.pop();//末データ削除（担当者がクリアできなかったため、挿入したものをわざわざ削除処理追加）
                    newData.push(newRowMain);//新しいメインデータ挿入
                }
                //追加する行（空行）
                var newRow = {"sobjectType": cTaskObjectAPI,
                              "RecordTypeId":subTaskRecordTypeId,
                              "CategoryKbn__c":false,
                              "RecordType":{"Name":"Sub",
                                            "Id":subTaskRecordTypeId},
                              "selectedFlg__c":false};
                newData.push(newRow);
            }
        }
        //カテゴリ区分更新
        helper.setCategoryKbn(cmp, evt, newData);
        cmp.set("v.taskMasterList",newData);
    },
    //タスク削除
    delItem: function(component, event, helper) {
        //削除されるトランのレコードのIdの格納先
        var delData = [];
        var data = component.get("v.taskMasterList");
        var newData = [];
        var mainCheckedFlg = false;

        //リスト作り直し作業
        //チェックされたmainタスクから次のmainタスクまでのsubを含めて全部削除する
        for(var d of data){
            //チェックあり
            if(d.selectedFlg__c){
                if(d.RecordType.Name === 'Main'){
                    mainCheckedFlg = true;
                }
                //削除するレコードのId
                delData.push(d.Id);
                continue;
            }else{
                if(d.RecordType.Name === 'Main'){
                    mainCheckedFlg = false;
                }
            }
            //サブも削除する場合
            if(mainCheckedFlg){
                //削除するレコードのId
                delData.push(d.Id);
                //サブも削除
                continue;
            }
            newData.push(d);
        }
        //カテゴリ区分更新
        helper.setCategoryKbn(component, event, newData);
        component.set("v.taskMasterList",newData);

        //削除するレコードのIdを追加
        var orgDelData = component.get("v.delList");
        component.set("v.delList",orgDelData.concat(delData));
        //全削除後全選択にチェックをはずす
        component.set("v.checkAll", false);
    },
    //再読み込みボタン
    refreshItem : function (cmp, evt, helper){
        helper.initDisplay(cmp, evt);
    },
    //妥当性格納
    handleThorowValid : function (cmp, evt, helper){
        //eventからvalidを貰う
        var valid = evt.getParam("valid");
        //componentの属性に保持する
        var validList = cmp.get("v.validList");
        validList.push(valid);
        cmp.set("v.validList",validList);
    },
    //タスクコピー
    copyItem: function (component, event, helper) {
        var cTaskObjectAPI = component.get("v.cTaskObjectAPI");
        var mainTaskRecordTypeId = component.get("v.mainTaskRecordTypeId");
        var data = component.get("v.taskMasterList");
        var newData = [];
        var mainTaskChecked = false;
        var cnt = 0;
        var newRowsList = [];        
        var newRowSub;
        
        //リスト作り直し作業
        for(var d of data){            
            cnt++;
            //レコードタイプがMainの場合
            if(d.RecordType.Name === 'Main') {
                mainTaskChecked = false;
                //以前に選択済みが存在する場合
                if (newRowsList.length >= 1) {
                	newData.push.apply(newData,newRowsList);
                    //選択済みクリア
                    newRowsList = [];
                }
                if(d.selectedFlg__c){
					mainTaskChecked = true;
                    //選択済み情報コピー
                    var newRowMain = {"sobjectType": cTaskObjectAPI,
                                      "RecordTypeId":d.RecordTypeId,
                                      "Name":d.Name,
                                      "text1__c":d.text1__c,
                                      "user__r":d.user__r,
                                      "user__c":d.user__c,
                                      "Status__c":d.Status__c,
                                      "date__c":d.date__c,
                                      "DisplayNum__c":1,
                                      "SalesDistributionRate__c":d.SalesDistributionRate__c,
                                      "EstimatedManHour__c":d.EstimatedManHour__c,
                                      "SalesAmount__c":d.SalesAmount__c,
                                      "CategoryKbn__c":d.CategoryKbn__c,
                                      "RecordType":{"Name":"Main",
                                                    "Id":d.RecordTypeId},
                                      "selectedFlg__c":false};
                    newRowsList.push(newRowMain);
                }

            }

            newData.push(d);
            
            if(d.RecordType.Name === 'Sub' && d.selectedFlg__c){
                
                //値コピー
                newRowSub = {"sobjectType": cTaskObjectAPI,
                             "RecordTypeId":d.RecordTypeId,
                             "Name":d.Name,
                             "text1__c":d.text1__c,
                             "user__r":d.user__r,
                             "user__c":d.user__c,
                             "Status__c":d.Status__c,
                             "date__c":d.date__c,
                             "DisplayNum__c":1,
                             "SalesDistributionRate__c":d.SalesDistributionRate__c,
                             "EstimatedManHour__c":d.EstimatedManHour__c,
                             "SalesAmount__c":d.SalesAmount__c,
                             "CategoryKbn__c":d.CategoryKbn__c,
                             "RecordType":{"Name":"Sub",
                                           "Id":d.RecordTypeId},
                             "selectedFlg__c":false};
                
                if(mainTaskChecked){
                    newRowsList.push(newRowSub);
                }else{
                    newData.push(newRowSub);
                }
            }
            
            //最終行で時点で、コピー情報がある場合
            if(data.length === cnt　&& newRowsList.length >= 1){
                newData.push.apply(newData,newRowsList);
            }
        }
        //カテゴリ区分更新
        helper.setCategoryKbn(component, event, newData);
        component.set("v.taskMasterList",newData);
    },
    //全選択
    checkChanged : function(cmp, evt, helper){
        var checkAll = cmp.get("v.checkAll");
        var taskMasterList = cmp.get("v.taskMasterList");
        for(var tm of taskMasterList){
            tm.selectedFlg__c = checkAll;
        }
        cmp.set("v.taskMasterList",taskMasterList);
    }
})