({
    helperMethod : function() {

    },
    //初期情報取得
    initDo: function(cmp, evt){     
        var action = cmp.get("c.initDo");
        action.setParams({
            "recordId" : cmp.get("v.recordId"),
            "cTaskObjectAPI" : cmp.get("v.cTaskObjectAPI"),
            "userIdAPI" : cmp.get("v.userIdAPI"),
            "dateAPI" : cmp.get("v.dateAPI")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state ==="SUCCESS"){
                var ret = response.getReturnValue();
                //初期情報設定
                cmp.set("v.objectAPI", ret.objectAPI);
                cmp.set("v.statusList", ret.statusList);
                cmp.set("v.prefix", ret.prefix);
                cmp.set("v.mainTaskRecordTypeId", ret.mainTaskRecordTypeId);
                cmp.set("v.subTaskRecordTypeId", ret.subTaskRecordTypeId);
                cmp.set("v.taskMasterList", ret.taskMasterList);
                //削除リストをクリアする
                cmp.set("v.delList",[]);
                //全削除後全選択にチェックをはずす
                cmp.set("v.checkAll", false); 
            }else if(state ==="ERROR"){
                //To do : else ifでいいのか
                var errors = response.getError();
                if(errors){
                    var errorMsg　= "Unknown error";
                    if(errors[0]&&errors[0].message){
                        errorMsg = errors[0].message;
                    }
                }
                cmp.set("v.errorMessage",errorMsg);                
            }
        });
        $A.enqueueAction(action);
    },
    //タスク作成
    createTask : function(cmp,evt,taskMasterList,delList){
        //this.deleteTask(cmp,evt);
        var action = cmp.get("c.setTasks");
        action.setParams({
            "TaskList":taskMasterList,
            "pDelList":delList,
            "cTaskObjectAPI" : cmp.get("v.cTaskObjectAPI"),
            "recordId" : cmp.get("v.recordId")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state ==="SUCCESS"){
                var ret = response.getReturnValue();
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Success!",
                    message: "タスクが更新されました。",
                    type: "success"
                });
				toastEvent.fire();
                
                //全削除後全選択にチェックをはずす
                cmp.set("v.checkAll", false);
                //削除リストをクリアする
                cmp.set("v.delList",[]);
				//再読み込み
                cmp.set("v.taskMasterList",ret);
            }else{
                var errors = response.getError();
                var message = "Unknown error"; // Default error message
                // Retrieve the error message sent by the server
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Error!",
                    message: "タスク更新が失敗しました。"+ message,
                    type: "error"
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    //初期表示：トランのタスクを表示
    initDisplay : function(cmp, evt){
        var action = cmp.get("c.getTaskListofTran");
        var recordId = cmp.get("v.recordId");
        action.setParams({
            "cTaskObjectAPI":cmp.get("v.cTaskObjectAPI"),
            "recordId" : recordId
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state ==="SUCCESS"){
                var data = response.getReturnValue();
                cmp.set("v.taskMasterList",data);
                //削除リストをクリアする
                cmp.set("v.delList",[]);
                //全削除後全選択にチェックをはずす
                cmp.set("v.checkAll", false);
            }else{
                //To do : まだ丸々exceptionを投げてる
                //var action = cmp.get("c.getTaskListofTranTest");でテスト中
                var errors = response.getError();
                var message = "Unknown error"; // Default error message
                // Retrieve the error message sent by the server
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Error!",
                    message: "再読み込みが失敗しました。"+ message,
                    type: "error"
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    //テンプレ表示
    tempDisplay : function(cmp, evt){
        var action = cmp.get("c.getTaskList");
        action.setParams({
            "templateId" : evt.getParam("temp").Id,
            "objectAPI" : cmp.get("v.objectAPI"),
            "userIdAPI" : cmp.get("v.userIdAPI"),
            "dateAPI" : cmp.get("v.dateAPI"),
            "recordId" : cmp.get("v.recordId"),
            "cTaskObjectAPI" : cmp.get("v.cTaskObjectAPI"),
            "holidayChk" : cmp.get("v.holidayChk")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state ==="SUCCESS"){
                var data = response.getReturnValue();
                var origData = cmp.get("v.taskMasterList");
                //表示されてるタスクの下に追加
                origData.push.apply(origData,data);
                cmp.set("v.taskMasterList",origData);
            }else{
                var errors = response.getError();
                var message = "Unknown error";                
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Error!",
                    message: "テンプレート選択が失敗しました。"+ message,
                    type: "error"
                });
                toastEvent.fire();
            }
        })
        $A.enqueueAction(action);
    },
    //タスクリストのカテゴリ区分項目を更新する
    setCategoryKbn : function(cmp, evt, prmTmlist){
        var exMainFlg = false; //前タスクメイン判定フラグ
        var curMainFlg = false; //現タスクメイン判定フラグ

        //メインタスクのカテゴリ区分項目更新
        for(var i = 0; i < prmTmlist.length; i++) {
            var tm = prmTmlist[i];
            //現タスクメイン判定フラグ
            if(tm.RecordType.Name === 'Main') {
                curMainFlg = true;
            } else {
                curMainFlg = false;
            }
            // メインタスクが1件、またはラストタスクの場合
            if(prmTmlist.length==1 || (prmTmlist.length-1)==i){
                //現在のメインタスクのカテゴリ区分更新
                prmTmlist[i].CategoryKbn__c = false;
            }
            //サブタスクがない
            if(curMainFlg && exMainFlg){
                //１つ前のメインタスクのカテゴリ区分更新
                prmTmlist[i-1].CategoryKbn__c = false;
            }
            //前タスクメイン判定フラグ設定
            exMainFlg = curMainFlg;
        }        
    }
})