({
    
    getPageTitle : function(component, event, helper) {
		return '売買物件のお問合せ';
	},
	getMsg: function(component, event, helper) {
		return '内容を確認の上、後ほど、弊社担当者よりご連絡させていただきます。\n他にも多数の物件をご紹介しておりますので、ご興味のある物件が\nございましたら、ぜひお気軽にお問合せください。';
	},
        
    dispContactInfo : function(component, event, helper) {
        return false;
	},
})