({
    getPageTitle : function(component, event, helper) {
		return 'ご売却のご相談、査定のお申込み';
	},
    
	getMsg: function(component, event, helper) {
		return '内容を確認の上、後ほど、弊社担当者よりご連絡させていただきます。\nその他、何かご不明な点等がございましたら、お気軽にお問合せください。';
	},  
})