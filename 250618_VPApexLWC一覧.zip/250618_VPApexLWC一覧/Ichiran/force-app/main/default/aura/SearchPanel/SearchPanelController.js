({
    submitSQOL : function(cmp, event) {
        var searchAreaSQOL = cmp.get("v.searchAreaSQOL");
        var searchDetailSQOL = cmp.get("v.searchDetailSQOL");
        var type = cmp.get("v.RecordType");
        var soqlString = "";
        var appEvent = $A.get("e.c:articlesItemUpdate");
        var andTrigger = false;
        
        if(searchAreaSQOL) {
            soqlString += "(" + searchAreaSQOL + ")";
            andTrigger = true;
        }
        
        if(searchDetailSQOL) {
            if(andTrigger) {
                soqlString += " AND ";
            }
            soqlString += "(" + searchDetailSQOL + ")";
            andTrigger = true;
        }
        if(type){
            if(andTrigger) {
                soqlString += " AND ";
            }
            soqlString += " RecordType.DeveloperName ='" + type + "' ";
        }
        appEvent.setParams({ "whereSOQLString" : soqlString});
        appEvent.fire();
	},
    updateSearchAreaSQOL : function(cmp, event) {
        var message = event.getParam("whereSOQLString");
        cmp.set("v.searchAreaSQOL", message);
    },
    updateSearchDetailSQOL : function(cmp, event) {
        var message = event.getParam("whereSOQLString");
        cmp.set("v.searchDetailSQOL", message);
    },
    showSpinner : function (component, event, helper) {
        if(document.getElementById("SearchPanel").style) {
            document.getElementById("SearchPanel").style.display = "none";
        }
        
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        
        evt.setParams({ isVisible : true });
        evt.fire();    
    },
    doneWaiting : function (component, event, helper) {
        var SearchPanelElement = document.getElementById("SearchPanel");
        var loadingElement = document.getElementById("loading");
        
        if(SearchPanelElement && loadingElement) {
            SearchPanelElement.style.display = "block";
            loadingElement.style.display = "none";
            
            var spinner = component.find('spinner');
            var evt = spinner.get("e.toggle");
            
            evt.setParams({ isVisible : false });
            evt.fire();
        }        
    }
})