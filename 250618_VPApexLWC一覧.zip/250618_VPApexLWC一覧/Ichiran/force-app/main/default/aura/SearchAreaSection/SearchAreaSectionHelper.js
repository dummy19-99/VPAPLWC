({
	updateSOQLstring : function(cmp) {
        // 20190528 goto 一件しかない場合に表示しない場合に想定通りの動きにならないため修正
		//var chk_main = cmp.find("chk_main");
		//var chk_sub = cmp.find("chk_sub");
		var chk_main =  cmp.find("chk_main").length > 0 ? cmp.find("chk_main") : new Array(cmp.find("chk_main"));
        var chk_sub =  cmp.find("chk_sub").length > 0 ? cmp.find("chk_sub") : new Array(cmp.find("chk_sub"));
        var toggleMajorSmallMode = cmp.get("v.toggleMajorSmallMode");
        var soqlString = "";
        var andTrigger = false;
        var countMain = 0;

        for(var i = 0 ; i < chk_main.length ; i++) {
            if(chk_main[i].get("v.checked") == true) {
                var value = chk_main[i].get("v.value");
                var splitVal = value.split(" ");

                if(countMain > 0) {
                    soqlString += " OR ";
                }

                soqlString += " (";

                if(toggleMajorSmallMode) {
                    soqlString += " AreaMajorClassification__c LIKE '" + splitVal[0] + "'";
                } else {
                    soqlString += " AreaMiddleClassification__c LIKE '" + splitVal[0] + "'";
                }

                soqlString += ") ";
                countMain += 1;
                andTrigger = true;
            }
        }

        if(soqlString.length > 0) {
            soqlString += " OR ";
        }

        var countSub = 0;

        for(var i = 0 ; i < chk_sub.length ; i++) {
            if(chk_sub[i].get("v.checked") == true) {
                var value = chk_sub[i].get("v.value");
                var splitVal = value.split("_");

                if(countSub > 0) {
                    soqlString += " OR ";
                }

                soqlString += " (";

                if(toggleMajorSmallMode) {
                    soqlString += " AreaMajorClassification__c LIKE '" + splitVal[0].split(" ")[0] + "' AND AreaMiddleClassification__c LIKE '" + splitVal[1].split(" ")[0] + "'";
                } else {
                    soqlString += " AreaMiddleClassification__c LIKE '" + splitVal[0].split(" ")[0] + "' AND AreaSmallClassification__c LIKE '" + splitVal[1].split(" ")[0] + "'";
                }

                soqlString += ") ";
                countSub += 1;
            }
        }

        var cmpEvent = cmp.getEvent("sendSearchAreaArticleEvent");

        cmpEvent.setParams({
            "whereSOQLString" : soqlString });
        cmpEvent.fire();
	},
    getMajorMiddleClass : function(cmp) {
        var action = cmp.get("c.getOptionsListMajor");
        action.setParams({ "type" : cmp.get("v.RecordType"), "Syueki" : cmp.get("v.Syueki")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                cmp.set('v.propertyTypeOptions', response.getReturnValue());
            }
            else if (state === "INCOMPLETE") {
                // do something
                console.log("INCOMPLETE")
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });

        $A.enqueueAction(action);
        return true;
    },
    getMiddleSmallClass : function(cmp) {
        // 20190528 goto 一件しかない場合に表示しない場合に想定通りの動きにならないため修正
        //var chk_sub = cmp.find("chk_sub");
        var chk_sub =  cmp.find("chk_sub").length > 0 ? cmp.find("chk_sub") : new Array(cmp.find("chk_sub"));
        var countSub = 0;
        var soqlString = "";

        for(var i = 0 ; i < chk_sub.length ; i++) {
            if(chk_sub[i].get("v.checked") == true) {
                var value = chk_sub[i].get("v.value");
                var splitVal = value.split("_");

                if(countSub > 0) {
                    soqlString += " OR ";
                }

                soqlString += " (";
                soqlString += " AreaMajorClassification__c LIKE '" + splitVal[0].split(" ")[0] + "' AND AreaMiddleClassification__c LIKE '" + splitVal[1].split(" ")[0] + "'";
                soqlString += ") ";
                countSub += 1;
            }
        }

        if(countSub > 5) {
            alert("市区郡の選択が5件を超えています");
            return false;
        }

        if(countSub == 0) {
            alert("市区郡を選択してください （最大5件）");
            return false;
        }

        var action = cmp.get("c.getOptionsListMiddle");

        action.setParams({ "soqlString" : soqlString});

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('received respond')
                console.log(response.getReturnValue())
                cmp.set('v.propertyTypeOptions', response.getReturnValue());
            }
            else if (state === "INCOMPLETE") {
                // do something
                console.log("INCOMPLETE")
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });

        $A.enqueueAction(action);
        return true;
    },
    toggleSearchArea: function(cmp) {
        var toggleBoolean = cmp.get('v.toggleSearchArea');
        var searchAreaBodyElement = document.getElementById('searchAreaBody');
        if(searchAreaBodyElement) {
            if(toggleBoolean == true) {
                searchAreaBodyElement.style.display = 'none';
            } else {
                searchAreaBodyElement.style.display = '';
            }
        }
    }
})