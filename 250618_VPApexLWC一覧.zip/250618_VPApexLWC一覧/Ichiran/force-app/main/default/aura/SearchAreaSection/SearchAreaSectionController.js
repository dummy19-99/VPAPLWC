({
	init: function (cmp, event, helper) {
        helper.getMajorMiddleClass(cmp);
		cmp.set("v.toggleSearchArea", false);
    },
    submitTheSOQL : function (cmp, event, helper) {
        var cmpEvent = cmp.getEvent("submitSOQLEvent");
        
        cmpEvent.setParams({
            "whereSOQLString" : "searchDetail" });
        cmpEvent.fire();
    },
    getSmallClass : function (cmp, event, helper) {
        var toggleMajorSmallMode = cmp.get("v.toggleMajorSmallMode");
        
        if(toggleMajorSmallMode) {
            if(!helper.getMiddleSmallClass(cmp)){
                return;
            }
        } else {
            if(!helper.getMajorMiddleClass(cmp)){
                return;
            }
        }
        
        cmp.set("v.toggleMajorSmallMode", !toggleMajorSmallMode);
    },
    hideOrShow : function (cmp, event, helper) {        
        var toggleBoolean = cmp.get('v.toggleSearchArea');
        cmp.set('v.toggleSearchArea', !toggleBoolean); 
        helper.toggleSearchArea(cmp);
        
    },
    updateTheSOQL : function(cmp, event, helper) {
        helper.updateSOQLstring(cmp);
	},
    checkAll : function (cmp, event, helper) {
        var source = event.getSource();
        var name = source.get("v.name");
        var chk_main = cmp.find("chk_main");
        // 20190528 goto 一件しかない場合に表示しない場合に想定通りの動きにならないため修正
        //var chk_sub = cmp.find("chk_sub");
        var chk_sub =  cmp.find("chk_sub").length > 0 ? cmp.find("chk_sub") : new Array(cmp.find("chk_sub"));
        var value = source.get("v.checked");
        
        for(var i = 0 ; i < chk_sub.length ; i++) {
            var chk_sub_name = chk_sub[i].get("v.name");
            var searchResult = chk_sub_name.search("chkSub_" + name.split("_")[1])
            
            if(searchResult != -1) {
                chk_sub[i].set("v.checked", value);
            }
        }
        
        helper.updateSOQLstring(cmp);
    },
    doneWaiting : function (cmp, event, helper) {
        var device = $A.get("$Browser.formFactor");
        if(device == 'PHONE') {
            cmp.set('v.toggleSearchArea', true);
        }
        helper.toggleSearchArea(cmp);
    }
})