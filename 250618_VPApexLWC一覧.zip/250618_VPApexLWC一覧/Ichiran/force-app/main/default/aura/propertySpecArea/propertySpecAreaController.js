({
    // お問い合わせ物件情報の表示/非表示を切り替える
    confirmationPropertyDisp:function(component, event, helper) {
        helper.setConfirmationPropertyClass(component, event, helper,"spec_box_opener_Id");
    },
})