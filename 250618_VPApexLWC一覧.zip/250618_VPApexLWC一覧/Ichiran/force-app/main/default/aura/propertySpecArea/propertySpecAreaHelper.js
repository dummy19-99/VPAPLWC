({
    // お問い合わせ物件情報の表示/非表示を切り替える
    setConfirmationPropertyClass : function(component, event, helper, auraId) {
        
        var target = component.find(auraId);   
        
        for(var i=0; i <target.length; i++){
            if ($A.util.hasClass(target[i], "esws_opened")) {
                $A.util.addClass(target[i], 'esws_closed');
                $A.util.removeClass(target[i], 'esws_opened');
            } else {
                $A.util.addClass(target[i], 'esws_opened');
                $A.util.removeClass(target[i], 'esws_closed');
            }
        }
    },
})