({
    myAction : function(component, event, helper) {
        
    },
    tmpSelect : function(cmp, evt, helper){
        //sObject
        var temp = cmp.get("v.selectedLookUpRecord");
        if(temp.Id != undefined){
            var appEvt = $A.get("e.c:TaskCreator_Event");
            appEvt.setParams({"temp":temp,
                              "tran":"false"});
            appEvt.fire();
        }else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: "Warning!",
                message: "テンプレートを選んでください。",
                type: "warning"
            });
            toastEvent.fire();
        }
    }
})