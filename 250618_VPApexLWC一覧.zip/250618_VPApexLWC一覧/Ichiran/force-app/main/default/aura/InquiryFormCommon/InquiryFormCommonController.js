({
    // 初期化
    Init : function(component, event, helper) {
        
        // リードの初期化
        var inquiryInput = component.get("v.inquiryInput");
                
        if(inquiryInput){
            // 戻ってきた場合に再度値を設定する
            helper.getCheckAllMethod(component, event, helper);   
        }
        
    },

    // お問合せエリア入力チェック
    onInquiryAreaCheck : function(component, event, helper) {
        const selected = event.getSource().get("v.label");
        component.set("v.inquiryInput.InquiryArea__c", selected);
        helper.setInquiryAreaCheck(component, event, helper);
	},
    
    // 姓名入力チェック用
	onLastNameCheck : function(component, event, helper) {
        // 姓チェック
        helper.setLastNameCheck(component, event, helper);
    },
    
    // 姓名入力チェック用
	onFirstNameCheck : function(component, event, helper) {
        // 名チェック
        helper.setFirstNameCheck(component, event, helper);
    },
    
    // セイカナ入力チェック用
	onLastNameKanaCheck : function(component, event, helper) {
        // セイカナチェック
        helper.setLastNameKanaCheck(component, event, helper);
    },
    
    // メイカナ入力チェック用
	onFirstNameKanaCheck : function(component, event, helper) {
        // メイカナチェック
        helper.setFirstNameKanaCheck(component, event, helper);
    },  
    
    // E-mail入力チェック用
	onEmailCheck : function(component, event, helper) {
        // E-mailチェック
        helper.setEmailCheck(component, event, helper);
        
    },
    
    // 電話番号入力チェック用
    onTelCheck : function(component, event, helper) {
        // 電話番号チェック
        helper.setTelCheck(component, event, helper);
        
    },
        
    // 都道府県変更時
	changeCustomerState : function(component, event, helper) {
        
        var selected = event.getSource().get("v.value");
        
        helper.setCustomerAddress(component, event, helper, selected,"","", "");
        
    },
    // 郵便番号(お客様)のフォーカスを外した時
	onCustomerZipCodeCheck : function(component, event, helper) {
        
        var zipcode = component.get("v.inquiryInput.CustomerZipCode__c");
        
        if(zipcode){
            helper.zipCodeSearchCallback(component, ( helper.isInteger(zipcode) && zipcode.length === 7 ), "v.customerZipCodeInputCheckViewMap");      
        }else{
            helper.setInputCheckViewMap(component, "v.customerZipCodeInputCheckViewMap", '','','');
        }
        
    }, 
    
    // 郵便番号(お客様)検索ボタンクリック時
	clickCustomerZipCode : function(component, event, helper) {
        
        var zipcode = component.get("v.inquiryInput.CustomerZipCode__c");
        
        if(!!zipcode && helper.isInteger(zipcode) && zipcode.length === 7){
            helper.zipCodeSearch(component, event, helper, zipcode, function(response){
                
                //結果通知後に呼ばれる
                var retValue = JSON.parse(response);
                
                if(!!retValue){
                    
                    if(!!retValue.results && retValue.results.length > 0){
                        // チェック結果を保持する(戻る押下時に再度外部APIをコールすることでパフォーマンスが悪くなるため)
                        helper.setSearchAddressResult(component, "v.searchCustomerAddressResult", retValue.results[0].address1,retValue.results[0].address2,retValue.results[0].address3);
                        // 住所を設定する
                        helper.setCustomerAddress(component, event, helper, retValue.results[0].address1, retValue.results[0].address2, retValue.results[0].address3, "");
                    }
                }
            },{})            
        }

    }, 
    
    next: function(component, event, helper) {
        helper.next(component, event, helper);
    },
        
     // 確認画面へ遷移する
    nextOverride: function(component, event, helper) {
        component.getConcreteComponent().next();
    }, 
    

})