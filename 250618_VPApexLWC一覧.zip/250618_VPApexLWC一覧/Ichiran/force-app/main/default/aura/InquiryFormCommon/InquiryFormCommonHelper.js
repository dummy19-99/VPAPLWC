({
    
    // リードの初期化
	initLead : function(component, event, helper, callback) {
        
        // Apex
        var action = component.get("c.newLead");

        action.setCallback(this, function(data) {
            
            var rslt = data.getState();
            
            if (rslt === "SUCCESS"){
                component.set("v.inquiryInput", data.getReturnValue());
                if(!!callback){
                    callback.call();
                }
            }
        });
        $A.enqueueAction(action);
    }, 
        
    getState : function(){
        return ["北海道","青森県","岩手県","宮城県","秋田県","山形県","福島県","茨城県","栃木県","群馬県","埼玉県"
                ,"千葉県","東京都","神奈川県","新潟県","富山県","石川県","福井県","山梨県","長野県","岐阜県","静岡県"
                ,"愛知県","三重県","滋賀県","京都府","大阪府","兵庫県","奈良県","和歌山県","鳥取県","島根県","岡山県"
                ,"広島県","山口県","徳島県","香川県","愛媛県","高知県","福岡県","佐賀県","長崎県","熊本県","大分県"
                ,"宮崎県","鹿児島県","沖縄県"];
    },
    
    // 都道府県の初期化
    initState : function(component, auraId){
        this.setOption(component, this.getState(), auraId);
    },

    //エリア入力チェック
    setInquiryAreaCheck : function(component, event, helper){
        const fieldValue = component.get("v.inquiryInput.InquiryArea__c");
        return helper.requiredCheck(component, fieldValue, "v.inquiryAreaInputCheckViewMap", '「エリア」は必須です。');
    },
    
    // 姓チェック
    setLastNameCheck : function(component, helper) {
        var fieldValue = component.get("v.inquiryInput.LastName");
        return this.requiredCheck(component, fieldValue,"v.lastNameInputCheckViewMap", '「姓」は必須です。');
    },
    
    // 名チェック
    setFirstNameCheck : function(component, helper) {
        var fieldValue = component.get("v.inquiryInput.FirstName");
        return this.requiredCheck(component, fieldValue,"v.firstNameInputCheckViewMap", '「名」は必須です。');
    },
    
    // セイカナチェック
    setLastNameKanaCheck : function(component, helper) {

        var result = false;
        var fieldValue = component.get("v.inquiryInput.LastNameKana__c");
         
        result = this.requiredCheck(component, fieldValue,"v.lastNameKanaInputCheckViewMap", '「セイ」は必須です。');
        result = this.isKatakana(fieldValue);
        
        if(result === false){
            this.setInputCheckViewMap(component, "v.lastNameKanaInputCheckViewMap",'eswsFeedbackAlert','eswsFeedbackErrorField','「セイ」はカタカナで入力してください。');
        }
        
        return result;
    },
    
    // メイカナチェック
    setFirstNameKanaCheck : function(component, helper) {
        
        var result = false;
        var fieldValue = component.get("v.inquiryInput.FirstNameKana__c");
         
        result = this.requiredCheck(component, fieldValue,"v.firstNameKanaInputCheckViewMap", '「メイ」は必須です。');
        result = this.isKatakana(fieldValue);
        
        if(result === false){
            this.setInputCheckViewMap(component, "v.firstNameKanaInputCheckViewMap",'eswsFeedbackAlert','eswsFeedbackErrorField','「メイ」はカタカナで入力してください。');
        }
        
        return result;
    },
    
    // 必須チェック
    requiredCheck : function(component, fieldValue, targetMapName, ErrMsg) {
        
        if(!fieldValue || fieldValue.length === 0){
            this.setInputCheckViewMap(component, targetMapName,'eswsFeedbackAlert','eswsFeedbackErrorField', ErrMsg );
            return false;
        }else{
            this.setInputCheckViewMap(component, targetMapName,'eswsFeedbackOk','','');
            return true;
        } 
    },  
    
    // 任意チェック
    anyCheck1 : function(component, fieldValue, targetMapName) {
        
        if(!fieldValue || fieldValue.length === 0){
            this.setInputCheckViewMap(component, targetMapName,'','', '');
        }else{
            this.setInputCheckViewMap(component, targetMapName,'eswsFeedbackOk','','');
        }
        return true;
    }, 
    
    // 任意チェック
    anyCheck2 : function(component, fieldValue, targetMapName, ErrMsg, callback) {
        
        if(!fieldValue || fieldValue.length === 0){
            this.setInputCheckViewMap(component, targetMapName,'','', '');
            return true;
        }else if(callback(fieldValue) === false){
            this.setInputCheckViewMap(component, targetMapName,'eswsFeedbackAlert','eswsFeedbackErrorField', ErrMsg);
            return false;
        }else{
            this.setInputCheckViewMap(component, targetMapName,'eswsFeedbackOk','','');
            return true;
        } 
    },  

    // ご連絡先チェック 
    contactInformationCheck : function(component, attr1, attr2, value1, value2) {
        
        // 空白チェック
        if( (!value1 || value1.length === 0) && (!value2 || value2.length === 0)){
            this.setInputCheckViewMap(component, attr1,'eswsFeedbackAlert','eswsFeedbackErrorField','いずれかのご連絡先を入力してください。');
            this.setInputCheckViewMap(component, attr2,'eswsFeedbackAlert','eswsFeedbackErrorField','いずれかのご連絡先を入力してください。');
            return false;
        }
        
        if( !value2 || value2.length === 0){
            this.setInputCheckViewMap(component, attr2,'','','');   
        }
        
        if( (!value1 || value1.length === 0) && (value2 != null && value2.length > 0) ){
            this.setInputCheckViewMap(component, attr1,'','','');    
            return true;
        }
        
        if( value1 != null && value1.length > 0){
            this.setInputCheckViewMap(component, attr1,'eswsFeedbackOk','','');  
            return true;    
        }
    },  
    
    // Emailチェック
    setEmailCheck : function(component, event, helper) {

        var result = false;
        
        // Email
        var email = component.get("v.inquiryInput.Email");
        
        // 電話番号
        var phone = component.get("v.inquiryInput.Phone");
                
        result = this.contactInformationCheck(component, "v.emailInputCheckViewMap", "v.phoneInputCheckViewMap",  email, phone );
        
        if( email != undefined && email != null && email.length > 0 && this.isEmailAddress(email) === false){
            this.setInputCheckViewMap(component, "v.emailInputCheckViewMap", 'eswsFeedbackAlert' ,'eswsFeedbackErrorField', '「メール」の形式が不正です。');
            result = false;
        }
        
        return result;
        
    },
    
    // 電話チェック
    setTelCheck : function(component, event, helper) {
        
        var result = false;
        
        // Email
        var email = component.get("v.inquiryInput.Email");
        
        // 電話番号
        var phone = component.get("v.inquiryInput.Phone");
        
        result = this.contactInformationCheck(component, "v.phoneInputCheckViewMap", "v.emailInputCheckViewMap",  phone, email );
        
        if( phone != undefined && phone != null && phone.length > 0 && this.isTelNumber(phone) === false){
            this.setInputCheckViewMap(component, "v.phoneInputCheckViewMap", 'eswsFeedbackAlert','eswsFeedbackErrorField', '正しい電話番号を入力してください。');
            result = false;
        }
        return result;
    },
    
    //　住所検索結果を保持するオブジェクトに値を設定する
    setSearchAddressResult : function(component, attrName, State, City, Street){
        var result = component.get(attrName);
        result.State = State;
        result.City = City;
        result.Street = Street;
        component.set(attrName, result);
    },
    
    //　チェック表示用マップに値を設定する
    setInputCheckViewMap : function(component, attrName, groupClass, groupFieldClass, errMsg){
        var result = component.get(attrName);
        result.groupClass = groupClass;
        result.groupFieldClass = groupFieldClass;
        result.errMsg = errMsg;
        component.set(attrName, result);
    },
    
    // チェック関数を全てコールする
    getCheckAllMethod : function(component, event, helper){
        
        return [helper.setInquiryAreaCheck(component, event, helper),
                helper.setLastNameCheck(component, event, helper),
                helper.setFirstNameCheck(component, event, helper),
                helper.setLastNameKanaCheck(component, event, helper),
                helper.setFirstNameKanaCheck(component, event, helper),
                helper.setEmailCheck(component, event, helper),
                helper.setTelCheck(component, event, helper)];
        
    },
                           
    //カタカナのときtrueを返す
    isKatakana : function (str){
        str = (str==null) ? "": str;
        if(str.match(/^[ァ-ヶー　]*$/)){    //"ー"の後ろの文字は全角スペースです。
            return true;
        }else{
            var reg = new RegExp(/^[ｦ-ﾟ]*$/);
  			return reg.test(str);
        }
	},
            
    //Eメールの書式が正しいときtrueを返す
    isEmailAddress : function(address){
        var regexp = /^[A-Za-z0-9]{1}[A-Za-z0-9_.-]*@{1}[A-Za-z0-9_.-]{1,}\.[A-Za-z0-9]{1,}$/;
        return regexp.test(address);
    },
    
    //電話番号の書式が正しいときtrueを返す
    isTelNumber : function(telStr){
        const telNum=telStr.replace(/[━.*‐.*―.*－.*\-.*ー.*\-]/gi,'');
        var regexp = /^(0[5-9]0[0-9]{8}|0[1-9][1-9][0-9]{7})$/;
        return regexp.test(telNum);
    },

    //整数チェック
    isInteger : function(numStr){
        var regexp = /^([1-9]\d*|0)$/;
        return regexp.test(numStr);
    },
    
    // 確認画面へ遷移する
    next: function(component, event, helper, funcList) {
        
        var checkAll = helper.getCheckAllMethod(component, event, helper);
        
        if(funcList != null && funcList.length > 0){
            checkAll = checkAll.concat(funcList);
        }

        if(checkAll.reduce(function(acc,cur){
            return acc&&cur;
        },true)){   
            
            var setEvent = component.getEvent("gotoNext");
            setEvent.setParams({
                "acquiredDataList": JSON.stringify(component.get("v.propertyViewList")),
                "inquiryInput":    JSON.stringify(component.get("v.inquiryInput")),
            });
            setEvent.fire();
        }
        document.getElementById("pageWrap").scrollIntoView(true);

    }, 
     
    
    // 市町村選択リストを設定する
    setCityOption: function(component, placeName, callback){
        
        var action = component.get("c.getAddressDetails");
        
        action.setParams({
            "StateName": placeName
        });
        
        action.setCallback(this, function(response) {
            
            var rslt = response.getState();
            
            if (rslt === "SUCCESS"){
                
                var retValue = response.getReturnValue();
                
                if(!retValue || retValue.length === 0){
                    return;
                }
                // JSONに変換
                var json =  JSON.parse(response.getReturnValue());
                
                // 市区郡情報を取り出す
                var citys = new Array();
                for (var i in json) {
                    for(var j in json[i].location){
                        citys.push(json[i].location[j].city);
                    }
                }
                
                 callback.call(component, citys);   
                
            }else if (state === "ERROR") {
                // generic error handler
                var errors = response.getError();
                if (errors) {
                    console.log("Errors", errors);
                    if (errors[0] && errors[0].message) {
                        throw new Error("Error" + errors[0].message);
                    }
                } else {
                    throw new Error("Unknown Error");
                }
            }
            
        });
        $A.enqueueAction(action);

    },   
    // 選択リストの情報を設定する
    setOption : function(component, data, auraId) {
    
        var inputSel = component.find( auraId );
        
        var opts=[];
        opts.push({"class": "optionClass", label: '選んでください', value: null});
        
        if(!!data){  
            for(var i=0;　i< data.length;　i++){
                opts.push({"class": "optionClass", label: data[i], value: data[i]});
            }
        }
        inputSel.set("v.options", opts);
        
    },    
    
        
    // 郵便番号検索
    zipCodeSearch : function(component, event, helper, zipCode, callback) {
        
        // Apex
        var action = component.get("c.zipCodeSearch");
        
        action.setParams({
            "ZipCode": zipCode
        });
        
        action.setCallback(this, function(response) {   
            
            var state = response.getState();
            
            if (state === "SUCCESS") { 
                var retValue = response.getReturnValue();
                callback.call(component, retValue);   
            } else if (state === "ERROR") {
                // generic error handler
                var errors = response.getError();
                if (errors) {
                    console.log("Errors", errors);
                    if (errors[0] && errors[0].message) {
                        throw new Error("Error" + errors[0].message);
                    }
                } else {
                    throw new Error("Unknown Error");
                }
            }
        });
        
         $A.enqueueAction(action);

    },
    
     // 郵便番号検索コールバック
    zipCodeSearchCallback: function(component, status, viewMapName) {
        
        if(status === true){
            this.setInputCheckViewMap(component, viewMapName, 'eswsFeedbackOk','','');
            return true;
        }else{
            this.setInputCheckViewMap(component, viewMapName, 'eswsFeedbackAlert','eswsFeedbackErrorField','正しい郵便番号を入力してください。');
            return false;
        }
    },
    
    // お客様住所情報を登録する
    setCustomerAddress: function(component, event, helper, State, City, Street, CityBlock) {
        
        this.setCityOption(component, State, function(response){
            //結果通知後に呼ばれる
            helper.setOption(component, response, "customerCityId");
            helper.setSelectValue(component, "customerStateId",     State);
            helper.setSelectValue(component, "customerCityId",      City);
            component.set("v.inquiryInput.CustomerStreet__c",    Street);
            component.set("v.inquiryInput.CustomerCityBlock__c", CityBlock);
        },{})

    }, 
    
    // 選択リストに値を設定する
    setSelectValue : function(component, auraId, value) {  
        component.find(auraId).set("v.value", value);
    },
    
    // 選択リストの値を取得する
    getSelectValue : function(component, auraId) {  
        return component.find(auraId).get("v.value");
    },   
})