({
    
    // お問い合わせ内容を設定する
    setInquiryContents: function(component, helper){
        
        var mapValue = new Map();
        
        mapValue.set("v.inquiryInput.InquiryContentsCheck1__c","現地を見たい･案内して欲しい");
        mapValue.set("v.inquiryInput.InquiryContentsCheck2__c","物件の情報が知りたい");
        mapValue.set("v.inquiryInput.InquiryContentsCheck3__c","販売状況を知りたい");
        mapValue.set("v.inquiryInput.InquiryContentsCheck4__c","資料・間取図が欲しい");
        mapValue.set("v.inquiryInput.InquiryContentsCheck5__c","購入に関して相談したい");
        mapValue.set("v.inquiryInput.InquiryContentsCheck6__c","その他");
        
        var auraElement =  component.find("inquiryContentsId").getElement();
        
        // 生成したdiv要素を追加する
        for (const key of mapValue.keys()) {
            
            if(component.get(key)){
                
                // divをメインエレメントとする
                var mainElement = component.mainElement =  document.createElement('div');
                
                // pを子エレメントとする
                var childElement = document.createElement('p');
                
                // pにテキストを設定する
                childElement.innerText = mapValue.get(key);
                
                helper.setChildElement(mainElement, childElement);
                // お問い合わせ内容にdivを設定する
                helper.setChildElement(auraElement, mainElement);
            }
        }
    },
    
    // お客様住所を設定する
    setCustomerAddress: function(component, helper){
        
        var inquiryInput = component.get("v.inquiryInput");
        
        if(!inquiryInput || inquiryInput.length){
            return;
        }
                
         var auraElement =  component.find("customerAddressId").getElement();
        
        // 郵便番号
        if(inquiryInput.CustomerZipCode__c){
            var zipElement = document.createElement('p');
            zipElement.innerText = '〒' + inquiryInput.CustomerZipCode__c;
            helper.setChildElement(auraElement, zipElement);
        }
        // 住所
        var address = inquiryInput.CustomerState__c ? inquiryInput.CustomerState__c : '';
        address += inquiryInput.CustomerCity__c ? inquiryInput.CustomerCity__c : '';
        address += inquiryInput.CustomerStreet__c ? inquiryInput.CustomerStreet__c : '';
        address += inquiryInput.CustomerCityBlock__c ? inquiryInput.CustomerCityBlock__c : '';
        address += inquiryInput.CustomerRemainingAddress__c ? inquiryInput.CustomerRemainingAddress__c : '';

        
        if(address){
            var customerAddressElement = document.createElement('p');
            customerAddressElement.innerText = address;
            helper.setChildElement(auraElement, customerAddressElement);
        }

    },
})