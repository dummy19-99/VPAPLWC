({
    // タイトルの設定
    getPageTitle : function(component, event, helper) {
        return '売買物件のお問合せ';
    },  
        
    dispContactInfo : function(component, event, helper) {
        return false;
	},
})