({
    downloadPdfFile : function(component,event,helper){
        
        // ArticleID
        var articleId = component.get("v.recordId");
        
        var location = window.location;
        
        var urlString = location.href;

        var baseURL = urlString.substring(0, urlString.indexOf("/s"));
        
        // 「戸建て」と「事業部」PDFを分ける
        console.log(component.get("v.property.Type__c"));
        var vfPageName = component.get("v.property.Type__c") == '戸建' ? 'PropertyMaterialsDetachedHousePDF' : 'PropertyMaterialsForBusinessPDF'
        
        if(!baseURL || baseURL.length === 0){
            location.href = '/apex/'+ vfPageName +'?recordId=' + articleId;
        }else{
            location.href = baseURL + '/s/sfsites/c/apex/'+ vfPageName +'?recordId=' + articleId;
        }     
        
    }
})