({
    updateSOQLstring: function(cmp) {
        var propertyTypeValue = cmp.find("propertyType").get("v.value");
        // 20190516 不要検索項目削除対応 goto
        //var imageInput = cmp.find("imageInput").get("v.value");
        var priceLowwerLimitVal = cmp.find("priceLowwerLimitVal").get("v.value");
        var priceUpperLimitVal = cmp.find("priceUpperLimitVal").get("v.value");
        var areaLowwerLimitVal = cmp.find("areaLowwerLimitVal").get("v.value");
        var areaUpperLimitVal = cmp.find("areaUpperLimitVal").get("v.value");
        var surfaceAreaLowwerLimitVal = cmp.find("surfaceAreaLowwerLimitVal").get("v.value");
        var surfaceAreaUpperLimitVal = cmp.find("surfaceAreaUpperLimitVal").get("v.value");
        var walkTimeInput = parseInt(cmp.find("walkTimeInput").get("v.value"));
        var buildingAgeInput = parseInt(cmp.find("buildingAgeInput").get("v.value"));
        
        var soqlString = "";
        var andTrigger = false;
        
        if(propertyTypeValue.length != 0) {
            // 20190516 検索条件変更 goto
            /*soqlString += " (";
            for(var i = 0 ; i < propertyTypeValue.length ; i++) {
                soqlString += " PropertyType__c LIKE '" + propertyTypeValue[i] + "%'";
                if(i < propertyTypeValue.legnth - 1) {
                    soqlString += " OR ";
                }
            }
            
            soqlString += ") ";
            */
            for(var i = 0 ; i < propertyTypeValue.length ; i++) {
                if(propertyTypeValue[i] === 'その他'){
                    // 種別情報を取得する
                    var propertyTypeOptions = cmp.get("v.propertyTypeOptions");
                    soqlString += "Type__c NOT IN (";
                    for (var j = 0; j < propertyTypeOptions.length; j++) {
                        // その他は除外
                        if(propertyTypeOptions[j].value ==='その他'){
                            continue;
                        }
                        soqlString += "'" + propertyTypeOptions[j].value + "'";
                        
                        if(j < propertyTypeOptions.length - 2) {
                            soqlString += " , ";
                        } 
                    }
                }else{
                    soqlString += " (";
                    soqlString += " Type__c = '" + propertyTypeValue[i]　+ "'";
                }
                soqlString += ") ";
                if(i < propertyTypeValue.length - 1) {
                    soqlString += " OR ";
                } 

            }
            andTrigger = true;
        }
        console.log(soqlString);
        if(priceLowwerLimitVal != "0" || priceUpperLimitVal != "0") {
            if(andTrigger) {
                soqlString += " AND ";
            }
            
            soqlString += " (";
            
            if(priceLowwerLimitVal != "0" && priceUpperLimitVal != "0") {
                soqlString += " Price__c >= " + priceLowwerLimitVal + " AND Price__c <=" + priceUpperLimitVal;
            } else if(priceLowwerLimitVal != "0" && priceUpperLimitVal == "0") {
                soqlString += " Price__c >= " + priceLowwerLimitVal;
            } else if(priceLowwerLimitVal == "0" && priceUpperLimitVal != "0") {
                soqlString += " Price__c <= " + priceUpperLimitVal;
            }
            
            soqlString += ") ";
            andTrigger = true;
        }
        
        if(areaLowwerLimitVal != "0" || areaUpperLimitVal != "0" ) {
            if(andTrigger) {
                soqlString += " AND ";
            }
            soqlString += " (";
            
            if(areaLowwerLimitVal != "0" && areaUpperLimitVal != "0") {
                soqlString += " Area__c >= " + areaLowwerLimitVal + " AND Area__c <=" + areaUpperLimitVal;
            } else if(areaLowwerLimitVal != "0" && areaUpperLimitVal == "0") {
                soqlString += " Area__c >= " + areaLowwerLimitVal;
            } else if(areaLowwerLimitVal != "0" && areaUpperLimitVal == "0") {
                soqlString += " Area__c <= " + areaUpperLimitVal;
            }
            
            soqlString += ") ";
            andTrigger = true;
        }
        
        if(surfaceAreaLowwerLimitVal != "0" || surfaceAreaUpperLimitVal != "0") {
            if(andTrigger) {
                soqlString += " AND ";
            }
            soqlString += " (";
            
            if(surfaceAreaLowwerLimitVal != "0" && surfaceAreaUpperLimitVal != "0") {
                soqlString += " LandArea__c >= " + surfaceAreaLowwerLimitVal + " AND LandArea__c <=" + surfaceAreaUpperLimitVal;
            } else if(surfaceAreaLowwerLimitVal != "0" && surfaceAreaUpperLimitVal == "0") {
                soqlString += " LandArea__c >= " + surfaceAreaLowwerLimitVal;
            } else if(surfaceAreaLowwerLimitVal != "0"	 && surfaceAreaUpperLimitVal == "0") {
                soqlString += " LandArea__c <= " + surfaceAreaUpperLimitVal;
            }
            
            soqlString += ") ";
            andTrigger = true;
        }
        
        if(walkTimeInput != "0") {
            if(andTrigger) {
                soqlString += " AND ";
            }
            soqlString += " (";
            for(var i = 1 ; i < walkTimeInput ; i++) {
                soqlString += " TransportationFacilities__c LIKE '%" + i + "分%'";
                if(i < walkTimeInput - 1) {
                    soqlString += " OR ";
                }
            }
            
            soqlString += ") ";
            andTrigger = true;
        }
        
        if(buildingAgeInput != -1) {
            if(andTrigger) {
                soqlString += " AND ";
            }
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear() - buildingAgeInput;
            
            if (dd < 10) {
                dd = '0' + dd;
            }
            
            if (mm < 10) {
                mm = '0' + mm;
            }

            today = yyyy + '-' + mm + '-' + dd;
            
            soqlString += " (";
            soqlString += " BuildingAge__c >= " + today;
            soqlString += ") ";
        }
        // 20190516 不要検索項目削除対応 goto
        //if(imageInput.length != 0) {            
        //    soqlString += " Thumbnail__cCHECKNULL";
        //}
        
        cmp.set("v.soqlSearchDetail", soqlString);
    },
    toggleSearchDetail: function(cmp) {
        var toggleBoolean = cmp.get('v.toggleSearchDetail');
        var searchDetailBodyElement = document.getElementById('searchDetailBody');
        
        if(searchDetailBodyElement) {
            if(toggleBoolean == true) {
                searchDetailBodyElement.style.display = 'none';
            } else {
                searchDetailBodyElement.style.display = '';
            }
        }
    }
})