({
    init: function (cmp, event, helper) {
        var priceLowwerLimit = {
            selectedPriceVal: 0,
            price: [
                { label: '下限なし', value:0, selected: true},
                // 20190516 検索項目追加対応 (500万円追加) goto
                { label: '500万円', value:5000000},
                { label: '1000万円', value:10000000},
                { label: '2000万円', value:20000000},
                { label: '3000万円', value:30000000},
                { label: '4000万円', value:40000000},
                { label: '5000万円', value:50000000},
                { label: '6000万円', value:60000000},
                { label: '7000万円', value:70000000},
                { label: '8000万円', value:80000000},
                { label: '9000万円', value:90000000},
                { label: '10000万円', value:100000000}
            ]
        };
        
        var priceUpperLimit = {
            selectedPriceVal: 0,
            price: [
                // 20190516 検索項目追加対応 (500万円追加) goto
                { label: '500万円', value:5000000},
                { label: '1000万円', value:10000000},
                { label: '2000万円', value:20000000},
                { label: '3000万円', value:30000000},
                { label: '4000万円', value:40000000},
                { label: '5000万円', value:50000000},
                { label: '6000万円', value:60000000},
                { label: '7000万円', value:70000000},
                { label: '8000万円', value:80000000},
                { label: '9000万円', value:90000000},
                { label: '10000万円', value:100000000},
                { label: '上限なし', value:0, selected: true}
            ]
        };
        
        var areaLowwerLimit = {
            selectedAreaVal: 0,
            area: [
                { label: '下限なし', value:0, selected: true},
                { label: '60㎡', value:60},
                { label: '70㎡', value:70},
                { label: '80㎡', value:80},
                { label: '90㎡', value:90},
                { label: '100㎡', value:100},
                { label: '120㎡', value:120},
                { label: '150㎡', value:150},
                { label: '200㎡', value:200}
            ]
        };
        
        var areaUpperLimit = {
            selectedAreaVal: 0,
            area: [
                { label: '60㎡', value:60},
                { label: '70㎡', value:70},
                { label: '80㎡', value:80},
                { label: '90㎡', value:90},
                { label: '100㎡', value:100},
                { label: '120㎡', value:120},
                { label: '150㎡', value:150},
                { label: '200㎡', value:200},
                { label: '上限なし', value:0, selected: true}
            ]
        };
        
        var surfaceAreaLowwerLimit = {
            selectedSurfaceAreaVal: 0,
            surfaceArea: [
                { label: '下限なし', value:0, selected: true},
                { label: '20坪', value:20},
                { label: '25坪', value:25},
                { label: '30坪', value:30},
                { label: '35坪', value:35},
                { label: '40坪', value:40},
                { label: '50坪', value:50},
                // 20190516 検索項目修正対応 (50坪以上変更) goto
                //{ label: '65坪', value:65},
                //{ label: '80坪', value:80}
                { label: '100坪', value:100},
                { label: '200坪', value:200},
                { label: '500坪', value:500},
                { label: '1000坪', value:1000}
            ]
        };
        
        var surfaceAreaUpperLimit = {
            selectedSurfaceAreaVal: 0,
            surfaceArea: [
                { label: '20坪', value:20},
                { label: '25坪', value:25},
                { label: '30坪', value:30},
                { label: '35坪', value:35},
                { label: '40坪', value:40},
                { label: '50坪', value:50},
                // 20190516 検索項目修正対応 (50坪以上変更) goto
                //{ label: '65坪', value:65},
                //{ label: '80坪', value:80}
                { label: '100坪', value:100},
                { label: '200坪', value:200},
                { label: '500坪', value:500},
                { label: '1000坪', value:1000},
                { label: '上限なし', value:0, selected: true}
            ]
        };
        
        var propertyType =  [
            // 20190516 検索条件変更 goto
            { label: 'マンション', value:'区分'},
            { label: ' 戸建', value:'戸建'},
            { label: '土地', value:'土地'},
            // 20190516 不要検索項目削除対応 goto
            //{ label: 'テラスハウス/タウンハウス', value:'テラスハウス/タウンハウス'},
            { label: '事業用', value:'事業用'}
            //20200406 その他は未使用のため非表示 miyoshi
            //{ label: 'その他', value:'その他'}
        ];

        
        var walkTime =  [
            { label: '5分以内', value:"5"},
            { label: '10分以内', value:"10"},
            { label: '15分以内', value:"15"},
            { label: '20分以内', value:"20"},
            { label: '指定なし', value:"0"}
        ];
        // 20190516 不要検索項目削除対応 goto
        /*var imageInput =  [
            { label: '外観写真あり', value:"1"}
        ];
        */
        var buildingAge =  [
            { label: '新築', value:"1"},
            { label: '3年以内', value:"3"},
            { label: '5年以内', value:"5"},
            { label: '10年以内', value:"10"},
            { label: '指定なし', value:"-1"}
        ];
        
        cmp.set('v.priceLowwerLimitOptions', priceLowwerLimit.price);
        cmp.set('v.priceUpperLimitOptions', priceUpperLimit.price);
        cmp.set('v.priceLowwerSelectedValue', priceLowwerLimit.selectedPriceVal);
        cmp.set('v.priceUpperSelectedValue', priceUpperLimit.selectedPriceVal); 
        
        cmp.set('v.areaLowwerLimitOptions', areaLowwerLimit.area);
        cmp.set('v.areaUpperLimitOptions', areaUpperLimit.area);
        cmp.set('v.areaLowwerSelectedValue', areaLowwerLimit.selectedAreaVal);
        cmp.set('v.areaUpperSelectedValue', areaUpperLimit.selectedAreaVal); 
        
        cmp.set('v.surfaceAreaLowwerLimitOptions', surfaceAreaLowwerLimit.surfaceArea);
        cmp.set('v.surfaceAreaUpperLimitOptions', surfaceAreaUpperLimit.surfaceArea);
        cmp.set('v.surfaceAreaLowwerSelectedValue', surfaceAreaLowwerLimit.selectedSurfaceAreaVal);
        cmp.set('v.surfaceAreaUpperSelectedValue', surfaceAreaUpperLimit.selectedSurfaceAreaVal); 
        
        cmp.set('v.propertyTypeOptions', propertyType); 
        cmp.set('v.walkTimeOptions', walkTime);
        // 20190516 不要検索項目削除対応 goto
        //cmp.set('v.imageInputOptions', imageInput);
        cmp.set('v.buildingAgeOptions', buildingAge);
        
        console.log("init")
        cmp.set('v.toggleSearchDetail', false);
    },    
    hideOrShow: function (cmp, event, helper) {
        var toggleBoolean = cmp.get('v.toggleSearchDetail');
        cmp.set('v.toggleSearchDetail', !toggleBoolean); 
        helper.toggleSearchDetail(cmp);        
    },
    submitTheSOQL: function (cmp, event, helper) {
        var cmpEvent = cmp.getEvent("submitSOQLEvent");
        
        cmpEvent.setParams({
            "whereSOQLString" : "searchDetail" });
        cmpEvent.fire();
    },
    updateTheSOQL: function (cmp, event, helper) {
        helper.updateSOQLstring(cmp);
        
        var cmpEvent = cmp.getEvent("sendSearchDetailArticleEvent");
        var soqlString = cmp.get("v.soqlSearchDetail");
        
        cmpEvent.setParams({
            "whereSOQLString" : soqlString });
        cmpEvent.fire();
    },
    doneWaiting: function (cmp, event, helper) {
        var device = $A.get("$Browser.formFactor");
        if(device == 'PHONE') {
            cmp.set('v.toggleSearchDetail', true);
        }
		helper.toggleSearchDetail(cmp);
    }
})