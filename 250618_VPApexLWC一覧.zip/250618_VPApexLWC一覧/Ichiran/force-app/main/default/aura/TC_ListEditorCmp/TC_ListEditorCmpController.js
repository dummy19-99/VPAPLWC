({
	doInit : function(component,event,helper) {
	  var objectName = component.get('v.objectName');
    var fields = component.get('v.fields');
    // SDC Mod Start
    //var rowsToLoad = component.get('v.viewRowsToLoad');
    var rowsToLoad = component.get('v.editRowsToLoad');
    // SDC Mod End
    var recordId = component.get('v.recordId');
    var parentField = component.get('v.parentField');
    var conditionsFilterList = component.get('v.conditionsFilterList');
    var orderField = component.get('v.orderField');
    var isOrderDESC = component.get('v.isOrderDESC');
    var offset = "0";
    // SDC Mod Start
    //helper.getRecordList(component, objectName, fields, rowsToLoad, recordId, parentField, offset, conditionsFilterList,isOrderDESC,orderField);
    helper.getRecordList(component, objectName, helper.addDefaultfields(fields), rowsToLoad, recordId, parentField, offset, conditionsFilterList,isOrderDESC,orderField);
    // SDC Mod End
	},
  refreshRecordList: function(cmp, event, helper){
    var parentField = event.getParam("parentField");

    cmp.set('v.parentField', parentField);
    
    var objectName = cmp.get('v.objectName');
    var fields = cmp.get('v.fields');
    // SDC Mod Start
    //var rowsToLoad = cmp.get('v.viewRowsToLoad');
    var rowsToLoad = cmp.get('v.editRowsToLoad');
    // SDC Mod End
    var recordId = cmp.get('v.recordId');
    var offset = "0";
    var isOrderDESC = cmp.get('v.isOrderDESC');
    var orderField = cmp.get('v.orderField');
    var conditionsFilterList = cmp.get('v.conditionsFilterList');
    // SDC Mod Start
    //helper.getRecordList(cmp, objectName, fields, rowsToLoad, recordId, parentField,offset,conditionsFilterList,isOrderDESC,orderField);
    helper.getRecordList(cmp, objectName, helper.addDefaultfields(fields), rowsToLoad, recordId, parentField,offset,conditionsFilterList,isOrderDESC,orderField);
    // SDC Mod End
  },
  // SDC Add Start
  doSearch: function(cmp, event, helper){
    var statusVal = event.getParam("statusVal");
    var dateVal = event.getParam("dateVal");
    var addItemVal = event.getParam("addItemVal");
    var queryStr = '';
    // SOQL条件形式に変換
    if(statusVal != null && statusVal != '' && statusVal != ' '){
      queryStr = " Status__c = " + "\'" + statusVal + "\'"; 
    }
    if(dateVal != null && dateVal != ''){
      if(queryStr != ''){
        queryStr = queryStr + ' AND '
      }
      queryStr = queryStr + ' date__c = ' + dateVal; 
    }
    if(addItemVal != null && addItemVal != ''){
      if(queryStr != ''){
        queryStr = queryStr + ' AND '
      }
      queryStr = queryStr + ' AddSearchItem__c LIKE ' + "\'\%" + addItemVal + "\%\'"; 
    }
    // 条件を画面設定
    cmp.set('v.conditionsFilterList', queryStr);
    //検索条件で一覧再取得
    var parentField = cmp.get('v.parentField');
    var objectName = cmp.get('v.objectName');
    var fields = cmp.get('v.fields');
    var rowsToLoad = cmp.get('v.editRowsToLoad');
    var recordId = cmp.get('v.recordId');
    var offset = "0";
    var isOrderDESC = cmp.get('v.isOrderDESC');
    var orderField = cmp.get('v.orderField');
    var conditionsFilterList = cmp.get('v.conditionsFilterList');
    helper.getRecordList(cmp, objectName, helper.addDefaultfields(fields), rowsToLoad, recordId, parentField,offset,conditionsFilterList,isOrderDESC,orderField);
  },
  doClearSearch: function(cmp, event, helper){
    // 画面の条件クリア
    cmp.set('v.conditionsFilterList', '');
    //クリア後、一覧再取得
    var parentField = cmp.get('v.parentField');
    var objectName = cmp.get('v.objectName');
    var fields = cmp.get('v.fields');
    var rowsToLoad = cmp.get('v.editRowsToLoad');
    var recordId = cmp.get('v.recordId');
    var offset = "0";
    var isOrderDESC = cmp.get('v.isOrderDESC');
    var orderField = cmp.get('v.orderField');
    var conditionsFilterList = cmp.get('v.conditionsFilterList');
    helper.getRecordList(cmp, objectName, helper.addDefaultfields(fields), rowsToLoad, recordId, parentField,offset,conditionsFilterList,isOrderDESC,orderField);
  }
  // SDC Mod End
})