({
    afterRender: function(component, helper) {
        this.superAfterRender();
        helper.setElementText(component, "innerMessageId",component.getConcreteComponent().getMsg());
    }
})