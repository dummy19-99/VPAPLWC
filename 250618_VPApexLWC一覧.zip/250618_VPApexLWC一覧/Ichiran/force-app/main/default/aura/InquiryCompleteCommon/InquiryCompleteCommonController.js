({
    getMsg: function(component, event, helper) {
        return '';
    },
})