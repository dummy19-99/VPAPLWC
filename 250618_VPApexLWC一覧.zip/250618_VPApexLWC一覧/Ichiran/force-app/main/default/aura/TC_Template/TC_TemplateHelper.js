({
    initDo : function(cmp, evt){
   		var action = cmp.get("c.initDo");
        action.setParams({
            "recordId":cmp.get("v.recordId")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                cmp.set("v.taskMasterList", returnValue.taskMasterList);
                cmp.set("v.mainRecordTypeId", returnValue.mainRecordTypeId);
                cmp.set("v.subRecordTypeId", returnValue.subRecordTypeId);
            }else{
                var errors = response.getError();
                var errorMsg　= "Unknown error";
                if(errors){
                    if(errors[0]&&errors[0].message){
                        errorMsg = errors[0].message;
                    }
                }
                cmp.set("v.errorMessage",errorMsg);
            }
        });
        $A.enqueueAction(action);
    },
    initDisplay : function(cmp, evt){
        var action = cmp.get("c.getTaskList");
        action.setParams({"recordId": cmp.get("v.recordId")});
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var taskMasterList = response.getReturnValue();
                cmp.set("v.taskMasterList", taskMasterList);
                //全選択にチェックをはずす
                cmp.set("v.checkAll", false);
                //削除リストをクリアする
                cmp.set("v.delList",[]);
                //validリストをクリアする
        		cmp.set("v.validList",[]);
            }else{
                var errors = response.getError();
                var message = "Unknown error"; // Default error message
                // Retrieve the error message sent by the server
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Error!",
                    message: "再読み込みが失敗しました。"+ message,
                    type: "error"
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
        
    },
    createTask: function(cmp, evt){
    	var action = cmp.get("c.setTasks");
        action.setParams({
            "taskList" : cmp.get("v.taskMasterList"),
            "recordId" : cmp.get("v.recordId"),
            "delList" : cmp.get("v.delList")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Success!",
                    message: "タスクが更新されました。",
                    type: "success"
                });
                toastEvent.fire();
                
				//再読み込み
                var taskMasterList = response.getReturnValue();
                cmp.set("v.taskMasterList", taskMasterList);
                //全選択にチェックをはずす
                cmp.set("v.checkAll", false);
            }else{
                var errors = response.getError();
                var message = "Unknown error"; // Default error message
                // Retrieve the error message sent by the server
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: "Error!",
                    message: "タスク更新が失敗しました。"+ message,
                    type: "error"
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    //タスクリストのカテゴリ区分項目を更新する
    setCategoryKbn : function(cmp, evt, prmTmlist){
        var mainRecordTypeId = cmp.get("v.mainRecordTypeId");
        var exMainFlg = false; //前タスクメイン判定フラグ
        var curMainFlg = false; //現タスクメイン判定フラグ

        //メインタスクのカテゴリ区分項目更新
        for(var i = 0; i < prmTmlist.length; i++) {
            var tm = prmTmlist[i];

            //現タスクメイン判定フラグ
            if(tm.RecordTypeId === mainRecordTypeId) {
                curMainFlg = true;
            } else {
                curMainFlg = false;
            }

            // メインタスクが1件
            if(prmTmlist.length==1 || (prmTmlist.length-1)==i){
                //現在のメインタスクのカテゴリ区分更新
                prmTmlist[i].CategoryKbn__c = false;
            }
            //サブタスクがない
            if(curMainFlg && exMainFlg){
                //１つ前のメインタスクのカテゴリ区分更新
                prmTmlist[i-1].CategoryKbn__c = false;
            }

            //前タスクメイン判定フラグ設定
            exMainFlg = curMainFlg;
        }
    }
})