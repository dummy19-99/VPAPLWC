({
    doInit : function(cmp, evt, helper){
        //初期表示：テンプレートに紐付くタスクを表示
        helper.initDo(cmp,evt);
        var dispSalesFlg = cmp.get("v.dispSalesFlg");//売上分配率制御フラグ
        var dispPlansFlg = cmp.get("v.dispPlansFlg");//予定情報制御フラグ
        if(dispSalesFlg){
            if(dispPlansFlg){
                cmp.set("v.styleSize","1000");
            } else {
                cmp.set("v.styleSize","800");
            }
        } else {
            if(dispPlansFlg){
                cmp.set("v.styleSize","900");
            } else {
                cmp.set("v.styleSize","700");
            }
        }
    },
    createTask : function(cmp, evt, helper){
        //項目検査結果クリア
        cmp.set("v.validList",[]);
        //メッセージクリア
        cmp.set("v.errorMessage","");
        //validを求めるevent
        var validEvent = $A.get("e.c:validEvent");
        validEvent.fire();
        //売上分配率制御フラグ
        var dispSalesFlg = cmp.get("v.dispSalesFlg");
        //メッセージ
        var errorMsg = [];

        var validList = cmp.get("v.validList");
        //項目の妥当性にfalseがない場合
        if(!validList.includes(false)){

            //売上分配率制御フラグがtrue
            if(dispSalesFlg){
                //売上分配率(%)の整合性チェック実施
                var mainRecordTypeId = cmp.get("v.mainRecordTypeId");
                var tmList = cmp.get("v.taskMasterList");
                var totalMainRate = 0;//totalMainRate
                var totalSubRate = 0;//totalsubRate
                var subExistFlg = false;//subExistFlg
                var mainName = "";//メインタスク名
                
                //売上分配率チェック
                for(var tm of tmList) {

                    //現タスクメイン判定フラグ
                    if(tm.RecordTypeId === mainRecordTypeId) {
                        
                        if(subExistFlg && (totalMainRate > 0 || totalSubRate > 0)){
                            //subが100%でない場合、
                            if(totalSubRate != 100){
                                //メッセージセット
                                var errMsgStr = $A.get("$Label.c.TC_ErrorMsg_TotalSubRate100");
                                errorMsg.push(errMsgStr.replace("mainName",mainName));
                            }
                        }
                        
                        if(tm.SalesDistributionRate__c != undefined){
                            //メインの売上分配率(%)を合算
                            totalMainRate = totalMainRate + Number(tm.SalesDistributionRate__c);
                        }
        
                        totalSubRate = 0; //サブ売上分配率(%)初期化
                        subExistFlg = false; //サブありフラグ初期化
                        mainName = tm.Name;//メイン名設定（エラーメッセージ用）
                    } else {
        
                        //subあり
                        subExistFlg = true;
        
                        if(tm.SalesDistributionRate__c != undefined){
                            //サブの売上分配率(%)を合算
                            totalSubRate = totalSubRate + Number(tm.SalesDistributionRate__c);
                        }
                    }
                }
                //subが100%でない場合、
                if(subExistFlg == true && totalSubRate != 100){
                    //メッセージセット
                    var errMsgStr = $A.get("$Label.c.TC_ErrorMsg_TotalSubRate100");
                    errorMsg.push(errMsgStr.replace("mainName",mainName));
                }
                //メインが100%でない場合、
                if(totalMainRate > 0 && totalMainRate != 100){
                    //メッセージセット
                    errorMsg.push($A.get("$Label.c.TC_ErrorMsg_TotalMainRate100"));
                }
            }
            if(errorMsg.length === 0){
                //エラーなし
                helper.createTask(cmp, evt);
            } else {
                var taostEvent = $A.get("e.force:showToast");
                taostEvent.setParams({
                    title: "Error!",
                    message: "" + errorMsg, //「""」ないとメッセージ表示されないため、「""」追加
                    type: "error"
                });
                taostEvent.fire();
            }
        }else{
            var taostEvent = $A.get("e.force:showToast");
            taostEvent.setParams({
                title: "Warning!",
                message: "入力に誤りがあります。確認してください。",
                type: "warning"
            });
            taostEvent.fire();
        }
    },
    delItem : function(cmp, evt, helper){
        //削除されるトランのレコードのIdの格納先
        var newDelList = [];
        var mainRecordTypeId = cmp.get("v.mainRecordTypeId");
        var taskMasterList = cmp.get("v.taskMasterList");  
       	var newList = [];
        var mainCheckedFlg = false;

        for(var tm of taskMasterList){
            //選択された場合
            if(tm.selectedFlg__c){
                //Mainの場合
                if(tm.RecordTypeId === mainRecordTypeId){
                    //サブも削除するよ
                    mainCheckedFlg = true;
                }
                //削除するId格納
                newDelList.push(tm.Id);
                continue;
            }else{
                //Mainの場合
                if(tm.RecordTypeId === mainRecordTypeId){
                    //サブも削除しないよ
                    mainCheckedFlg = false;
                }
            }
            //サブも削除する場合
            if(mainCheckedFlg){
                //削除するId格納
                newDelList.push(tm.Id);
                //サブも削除
                continue;               
            }
            newList.push(tm);    
        }
        //カテゴリ区分更新
        helper.setCategoryKbn(cmp, evt, newList);
        //リストデータ設定
        cmp.set("v.taskMasterList",newList);
        
        //削除リスト設定
        var oldDelList = cmp.get("v.delList");
        cmp.set("v.delList",oldDelList.concat(newDelList));
        
        //全選択にチェックをはずす
        cmp.set("v.checkAll", false);
    },
    refreshItem : function(cmp, evt, helper){
        helper.initDisplay(cmp,evt);
    },
    addItem : function(cmp, evt, helper){
        var mainRecordTypeId = cmp.get("v.mainRecordTypeId");
        var taskMasterList = cmp.get("v.taskMasterList");
        var newList = [];
        var mainCheckedFlg = false;
        var cnt = 0;
        
        //リストが存在しない場合
        if(taskMasterList.length === 0){
            var newRow = {"sobjectType" : "TaskMaster__c",
                          "RecordTypeId":mainRecordTypeId,
                          "CategoryKbn__c":false,
                          "RecordType":{"Name":"Main",
                                        "Id":mainRecordTypeId}};
            //空行の追加ができる
            newList.push(newRow);
        }else{
            
            //リストが存在する場合
            for(var tm of taskMasterList){
                cnt++;
                //Mainタスクの場合
                if(tm.RecordTypeId === mainRecordTypeId){
                    //追加することがあれば
                    if(mainCheckedFlg){
                        var newRow = {"sobjectType" : "TaskMaster__c",
                                      "RecordTypeId":mainRecordTypeId,
                                      "CategoryKbn__c":false,
                                      "RecordType":{"Name":"Main",
                                                    "Id":mainRecordTypeId}};
                        //空行を前に追加
                        newList.push(newRow);
                        //追加したから追加することないよ
                        mainCheckedFlg = false;
                    }
                    //選択された場合
                    if(tm.selectedFlg__c){
                        //追加することがあるよ
                        mainCheckedFlg = true;
                    }
                }
                
                //現在の行を追加
                newList.push(tm);
                
                //最後の場合,その後ろに空行を追加
                if(mainCheckedFlg && taskMasterList.length === cnt){
                    var newRow = {"sobjectType" : "TaskMaster__c",
                                  "RecordTypeId":mainRecordTypeId,
                                  "CategoryKbn__c":false,
                                  "RecordType":{"Name":"Main",
                                                "Id":mainRecordTypeId}};
                    //空行を前に追加
                    newList.push(newRow);
                }
            }
        }
        //カテゴリ区分更新
        helper.setCategoryKbn(cmp, evt, newList);
        cmp.set("v.taskMasterList",newList);
    },
    addSubItem : function(cmp, evt, helper){
        var subRecordTypeId = cmp.get("v.subRecordTypeId");//画面上のサブレコードタイプIDを取得
        var newList = [];
        var taskMasterList = cmp.get("v.taskMasterList");//画面上のタスクリストを取得
        var mainRecordTypeId = cmp.get("v.mainRecordTypeId");
        
        for(var tm of taskMasterList){
            newList.push(tm);
            if(tm.selectedFlg__c){
                if(tm.RecordTypeId === mainRecordTypeId){
                    tm.EstimatedManHour__c = null; // メインタスク.予定工数（時間）をクリア
                    tm.PlannedUnitPrice__c = null; // メインタスク.予定単価をクリア
                    tm.CategoryKbn__c = "true"; // メインタスク.カテゴリ区分=True
                }
                var newRow = {"sobjectType" : "TaskMaster__c",
                              "RecordTypeId":subRecordTypeId,
                              "CategoryKbn__c":false,
                              "RecordType":{"Name":"Sub",
                                            "Id":subRecordTypeId}};
               newList.push(newRow);
            }
        }
        //カテゴリ区分更新
        helper.setCategoryKbn(cmp, evt, newList);
        cmp.set("v.taskMasterList",newList);      
    },
    copyItem : function(cmp, evt, helper){
        
        var mainRecordTypeId = cmp.get("v.mainRecordTypeId");
        var subRecordTypeId = cmp.get("v.subRecordTypeId");
        var recordId = cmp.get("v.recordId");
        var taskMasterList = cmp.get("v.taskMasterList");
        var newList = [];
        var newRowMainList = [];
        var cnt = 0;
        var mainTaskChecked = false;       
        
        for(var tm of taskMasterList){
            cnt++;
            //Mainタスクの場合
            if(tm.RecordTypeId === mainRecordTypeId){
                mainTaskChecked = false;
                //追加することがあれば
                if(newRowMainList.length >0 && newRowMainList[0].sobjectType !== undefined){
                    //コピー行を追加
                	newList.push.apply(newList,newRowMainList);
                    //追加したから追加することないよ
                    newRowMainList = [];
                }
                //選択された場合
                if(tm.selectedFlg__c){
                    mainTaskChecked = true;
                    //追加することがあるよ
                    var newRowMain = {"sobjectType" : "TaskMaster__c",
                                      "RecordTypeId":mainRecordTypeId,
                                      "Name":tm.Name,
                                      "days__c":tm.days__c,
                                      "text1__c":tm.text1__c,
                                      "CategoryKbn__c":tm.CategoryKbn__c,
                                      "SalesDistributionRate__c":tm.SalesDistributionRate__c,
                                      "EstimatedManHour__c":tm.EstimatedManHour__c,
                                      "PlannedUnitPrice__c":tm.PlannedUnitPrice__c,
                                      "RecordType":{"Name":"Main",
                                                    "Id":mainRecordTypeId}};
                    newRowMainList.push(newRowMain);
                }
            }
            
            //現在の行を追加
            newList.push(tm);
            
            //Subタスクの場合
            if(tm.RecordTypeId === subRecordTypeId && tm.selectedFlg__c){
                var newRowSub = {"sobjectType" : "TaskMaster__c",
                                 "RecordTypeId":subRecordTypeId,
                                 "Name":tm.Name,
                                 "days__c":tm.days__c,
                                 "text1__c":tm.text1__c,
                                 "CategoryKbn__c":tm.CategoryKbn__c,
                                 "SalesDistributionRate__c":tm.SalesDistributionRate__c,
                                 "EstimatedManHour__c":tm.EstimatedManHour__c,
                                 "PlannedUnitPrice__c":tm.PlannedUnitPrice__c,
                                 "RecordType":{"Name":"Sub",
                                               "Id":subRecordTypeId}};
                if(mainTaskChecked){
                    newRowMainList.push(newRowSub);
                }else{
                	newList.push(newRowSub);
                }
            }
            
            //最後の場合,その後ろにコピー行を追加
            if(newRowMainList.length >0 && newRowMainList[0].sobjectType !== undefined && taskMasterList.length === cnt){
                //コピー行を追加
                newList.push.apply(newList,newRowMainList);
            }
        }
        //カテゴリ区分更新
        helper.setCategoryKbn(cmp, evt, newList);
        cmp.set("v.taskMasterList",newList);
    },    
    checkChanged : function(cmp, evt, helper){
        var checkAll = cmp.get("v.checkAll");
        var taskMasterList = cmp.get("v.taskMasterList");
        for(var tm of taskMasterList){
            tm.selectedFlg__c = checkAll;
        }
        cmp.set("v.taskMasterList",taskMasterList);
    },
    //子コンポーネント（MTE_TaskList）から妥当性を貰う
    handleThorowValid : function(cmp, evt, helper){
        var valid = evt.getParam("valid");        
        var validList = cmp.get("v.validList");
        //子コンポーネント（MTE_TaskList）から貰った個々の妥当性をリストとして保持
        validList.push(valid);
        cmp.set("v.validList",validList);
    }
})