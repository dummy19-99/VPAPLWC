({
    afterRender : function(component, helper) {
        
        this.superAfterRender();    

        // 売却物件住所を設定する
        helper.setSellPropertyAddress(component, helper);
        
        // 建物(専有)面積を設定する
        helper.setBuildingEexclusiveArea(component, helper);
        
        // 土地面積を設定する
        helper.setLandArea(component, helper);
        
        // 間取りを設定する
        helper.setFloorPlan(component, helper);
        
        // 竣工年月を設定する
        helper.setCompletionDate(component, helper);
        
        // ご希望価格を設定する
        helper.setDesiredPrice(component, helper);
                        
        // お客様名を設定する
        helper.setCustomerName(component, helper, "customerNameId");
        
        // 連絡先を設定する
        helper.setContactInformation(component, helper, "contactInformationId");
        
        // お客様住所を設定する
        helper.setCustomerAddress(component, helper);
    },
})