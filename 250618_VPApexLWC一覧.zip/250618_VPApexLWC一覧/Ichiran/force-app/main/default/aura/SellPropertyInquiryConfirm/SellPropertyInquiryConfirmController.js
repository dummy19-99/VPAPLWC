({
    // タイトルの設定
    getPageTitle : function(component, event, helper) {
        return 'ご売却のご相談、査定のお申込み';
    },
})