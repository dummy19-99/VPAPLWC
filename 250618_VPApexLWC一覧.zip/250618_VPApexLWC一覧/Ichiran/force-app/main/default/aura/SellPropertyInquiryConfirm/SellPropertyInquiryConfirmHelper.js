({
    // 売却物件住所を設定する
    setSellPropertyAddress: function(component, helper){
        
        var inquiryInput = component.get("v.inquiryInput");
        
        // 住所
        var address =  inquiryInput.SellPropertyZipCode__c ? '〒' + inquiryInput.SellPropertyZipCode__c + ' ' : '';
        address += inquiryInput.SellPropertyState__c ? inquiryInput.SellPropertyState__c : '';
        address += inquiryInput.SellPropertyCity__c ? inquiryInput.SellPropertyCity__c : '';
        address += inquiryInput.SellPropertyStreet__c ? inquiryInput.SellPropertyStreet__c : '';
        address += inquiryInput.SellPropertyCityBlock__c ? inquiryInput.SellPropertyCityBlock__c : '';
        address += inquiryInput.SellPropertyRemainingAddress__c ? inquiryInput.SellPropertyRemainingAddress__c : '';

        helper.setAddress(component,helper,"sellPropertyAddressId", address);

    },
    
    // お客様住所を設定する
    setCustomerAddress: function(component, helper){
        
        var inquiryInput = component.get("v.inquiryInput");
        
        // 住所
        var address =  inquiryInput.CustomerZipCode__c ? '〒' + inquiryInput.CustomerZipCode__c + ' ' : '';
        address += inquiryInput.CustomerState__c ? inquiryInput.CustomerState__c : '';
        address += inquiryInput.CustomerCity__c ? inquiryInput.CustomerCity__c : '';
        address += inquiryInput.CustomerStreet__c ? inquiryInput.CustomerStreet__c : '';
        address += inquiryInput.CustomerCityBlock__c ? inquiryInput.CustomerCityBlock__c : '';
        address += inquiryInput.CustomerRemainingAddress__c ? inquiryInput.CustomerRemainingAddress__c : '';

        helper.setAddress(component,helper,"customerAddressId", address);

    },
    

    // 住所を設定する
    setAddress: function(component, helper, auraId , address){
        
        var auraElement =  component.find(auraId).getElement();
        
        var addressElement = document.createElement('div');
        
        if(address){
            addressElement.innerText = address;
            helper.setChildElement(auraElement, addressElement);
        }
    },
    
    // 建物(専有)面積を設定する
    setBuildingEexclusiveArea: function(component, helper){
        helper.setUnitHoldingValue(component, "buildingEexclusiveAreaId", "約", component.get("v.inquiryInput.BuildingEexclusiveArea__c"), component.get("v.inquiryInput.BuildingExclusiveAreaDiv__c"));
    },
    
    // 土地面積を設定する
    setLandArea: function(component, helper){
        helper.setUnitHoldingValue(component, "landAreaId", "約", component.get("v.inquiryInput.LandArea__c"), component.get("v.inquiryInput.LandAreaDiv__c"));
    },
    
     // 間取りを設定する
    setFloorPlan: function(component, helper){
        helper.setUnitHoldingValue(component, "floorPlanId", "", component.get("v.inquiryInput.FloorPlan__c"), component.get("v.inquiryInput.FloorPlanTypes__c"));
    }, 
    
    // 竣工年月を設定する
    setCompletionDate: function(component, helper){
        helper.setUnitHoldingValue(component, "completionDateId", "", component.get("v.inquiryInput.CompletionDate__c"), "年");
    },
    
    // ご希望価格を設定する
    setDesiredPrice: function(component, helper){
        helper.setUnitHoldingValue(component, "desiredPriceId", "", component.get("v.inquiryInput.DesiredPrice__c"), "万円位");
    },
       
    // 約や㎡などの単位を持つ項目の設定
    setUnitHoldingValue: function(component, auraId , previousUnit , value , behindUnit){
        
        var auraElement =  component.find(auraId).getElement();
        
        
        var mainElement = component.mainElement = document.createElement('p');
        
        if(!!value){
            
            if(previousUnit){
                // 前単位
                this.setSpanElement(mainElement, previousUnit); 
            }
            
            // 値
            this.setSpanElement(mainElement, value);
            
            if(behindUnit){
                // 後単位
                this.setSpanElement(mainElement, behindUnit);
            }
        }
        this.setChildElement(auraElement, mainElement);
        
    },
    
    setSpanElement: function( mainElement, spanText ){
        var spanElement = document.createElement('span');
        spanElement.innerText = spanText;
        this.setChildElement(mainElement, spanElement);
    }
        

})