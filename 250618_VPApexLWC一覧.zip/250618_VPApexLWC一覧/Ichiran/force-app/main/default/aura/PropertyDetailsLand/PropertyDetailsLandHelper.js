({
    downloadPdfFile : function(component,event,helper){
        
        // ArticleID
        var articleId = component.get("v.recordId");
        
        var urlString = location.href;

        var baseURL = urlString.substring(0, urlString.indexOf("/s"));

        if(!baseURL || baseURL.length === 0){
            location.href = '/apex/PropertyMaterialsLandPDF?recordId=' + articleId;
        }else{
            location.href = baseURL + '/s/sfsites/c/apex/PropertyMaterialsLandPDF?recordId=' + articleId;
        }         
    },

})