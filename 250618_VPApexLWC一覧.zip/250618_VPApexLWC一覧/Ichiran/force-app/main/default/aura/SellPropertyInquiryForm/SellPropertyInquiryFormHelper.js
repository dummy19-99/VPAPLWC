({
    // チェックするメソッドを返す
    getSellPropertyAllMethod : function(component, event, helper) {
       
       return [helper.setPropertyTypeCheck(component, event, helper),
                               helper.setAreaCheck(component, event, helper),
                               helper.setFloorPlanTextCheck(component, event, helper),
                               helper.setCompletionDateCheck(component, event, helper),
                               helper.setDesiredPriceCheck(component, event, helper),
                               helper.setShoppingCheck(component, event, helper),
                               helper.setDesiredSaleTimeCheck(component, event, helper),
                               helper.setRequestCheck(component, event, helper),
                               helper.setRequiredSellPropertyAddress(component, event, helper)];
    },
    
    // 物件種別組み合わせチェック
	setPropertyTypeCheck : function(component, event, helper) {
        
        const fieldValue = component.get("v.inquiryInput.PropertyType__c");
        
        var result = this.requiredCheck(component, fieldValue, "v.propertyTypeInputCheckViewMap", '「物件種別」は必須です。');
        
        if(result){
            // 建物(専有)面積のチェック設定
            result = (this.setPropertyTypeCombination(component, component.get("v.inquiryInput.BuildingEexclusiveArea__c"), "v.buildingEexclusiveAreaInputCheckViewMap",  (fieldValue === '土地'), '土地の場合、建物(専有)面積は入力できません') && result);
            // 土地面積のチェック設定
            result = (this.setPropertyTypeCombination(component, component.get("v.inquiryInput.LandArea__c"), "v.landAreaInputCheckViewMap", (fieldValue === 'マンション'), 'マンションの場合、土地面積は入力できません') && result);
        }
        return result;
     
	},
    

    // 物件種別組み合わせ設定
	setPropertyTypeCombination : function(component, fieldValue, mapName, checkValue, errMsg) {
        
        // 空白の場合は空を設定する
        if(!fieldValue || fieldValue.length === 0){
            this.setInputCheckViewMap(component, mapName,'','', '');
            return true;
        }
            
        // 面積チェックを行う
        if( this.isArea(fieldValue) === false){
            this.setInputCheckViewMap(component, mapName, 'eswsFeedbackAlert','eswsFeedbackErrorField', "整数部「6桁」、小数部「2桁」までの数値を入力してください" );
            return false;
        }
        
        // 組合わせチェックを行う
        if(checkValue){
            this.setInputCheckViewMap(component, "v.propertyTypeInputCheckViewMap",'eswsFeedbackAlert','eswsFeedbackErrorField', errMsg);
            this.setInputCheckViewMap(component, mapName, 'eswsFeedbackAlert','eswsFeedbackErrorField', errMsg );
            return false;
        }
        
        // エラーがない場合OKとする
        this.setInputCheckViewMap(component, mapName,'eswsFeedbackOk','','');
        
        return true;
        
    },
   
    
    // 面積のエラー状態を設定
	setAreaCheck : function(component, event, helper) {
        
        const propertyTypeValue = component.get("v.inquiryInput.PropertyType__c");
        
        if(!!propertyTypeValue && propertyTypeValue.length > 0){
            this.requiredCheck(component, propertyTypeValue, "v.propertyTypeInputCheckViewMap", '「物件種別」は必須です。');
        }
        
        // 建物(専有)面積のチェック設定
        var result = this.setPropertyTypeCombination(component, component.get("v.inquiryInput.BuildingEexclusiveArea__c"), "v.buildingEexclusiveAreaInputCheckViewMap",  (propertyTypeValue === '土地'), '土地の場合、建物(専有)面積は入力できません');
        // 土地面積のチェック設定
        result = (this.setPropertyTypeCombination(component, component.get("v.inquiryInput.LandArea__c"), "v.landAreaInputCheckViewMap", (propertyTypeValue === 'マンション'), 'マンションの場合、土地面積は入力できません') && result);
        
        return result;
	},
    
     // 間取りのエラー状態を設定
	setFloorPlanTextCheck : function(component, event, helper) {
        
        const fieldValue = component.get("v.inquiryInput.FloorPlan__c");
        
        // チェックしたい関数
        var myCallback = function(numStr) {
            return helper.isInteger(numStr);
        }
        return helper.anyCheck2(component, fieldValue, "v.floorPlanInputCheckViewMap", "「間取り」は数字を入力してください", myCallback );
	},
    
    // 竣工年月のエラー状態を設定
	setCompletionDateCheck : function(component, event, helper) {
        
        const fieldValue = component.get("v.inquiryInput.CompletionDate__c");
        
        // チェックしたい関数
        var myCallback = function(numStr) {
            return helper.isInteger(numStr);
        }
        return helper.anyCheck2(component, fieldValue, "v.completionDateInputCheckViewMap", "正の整数を入力してください", myCallback );

	},  
    
    // ご希望価格のエラー状態を設定
	setDesiredPriceCheck : function(component, event, helper) {
        
        const fieldValue = component.get("v.inquiryInput.DesiredPrice__c");
        
        // チェックしたい関数
        var myCallback = function(numStr) {
            return helper.isInteger(numStr);
        }
        return helper.anyCheck2(component, fieldValue, "v.desiredPriceInputCheckViewMap", "「希望価格」は数字を入力してください", myCallback );

	},  
    
    // お買いかえエラー状態を設定
    setShoppingCheck : function(component, event, helper) {
        const fieldValue = component.get("v.inquiryInput.Shopping__c");
        return helper.anyCheck1(component, fieldValue, "v.shoppingInputCheckViewMap");
	},
    
    // 売買希望時期エラー状態を設定
    setDesiredSaleTimeCheck : function(component, event, helper) {
        const fieldValue = component.get("v.inquiryInput.DesiredSaleTime__c");
        return helper.anyCheck1(component, fieldValue, "v.desiredSaleTimeInputCheckViewMap");
	},
    
    // ご要望エラー状態を設定
    setRequestCheck : function(component, event, helper) {
        const fieldValue = component.get("v.inquiryInput.Request__c");
        return helper.anyCheck1(component, fieldValue, "v.requestInputCheckViewMap");
	},
    
    // 売買物件住所の表示状態を設定する
    setRequiredSellPropertyAddress :  function(component, event, helper) {
        
        var state = component.find("sellPropertyStateId").get("v.value");
        var city = component.find("sellPropertyCityId").get("v.value");
        var remainingAddress = component.get("v.inquiryInput.SellPropertyRemainingAddress__c");
        
        return helper.setRequiredAddress(component, state, city, remainingAddress);
    },

  
    // 必須住所を設定する
    setRequiredAddress: function(component, state, city, remainingAddress) {
        
        var errMsgList = new Array();
        
        // 都道府県
        if(this.requiredCheckField(component, state, 'v.sellPropertyAddressInputCheckViewMap.stateFieldClass') === false){
            errMsgList.push('「都道府県」は必須です。');
        }
        
        // 市区郡
        if(this.requiredCheckField(component, city, 'v.sellPropertyAddressInputCheckViewMap.cityFieldClass') === false){
            errMsgList.push('「市区郡」は必須です。');          
        }
        
        // 残り住所
        if(this.requiredCheckField(component, remainingAddress, 'v.sellPropertyAddressInputCheckViewMap.remainingFieldClass') === false){
            errMsgList.push('「残り住所」は必須です。');   
        }
        
        // エラーメッセージを設定する
        component.set('v.sellPropertyAddressInputCheckViewMap.errMsgList', errMsgList);
        
        if(!errMsgList || errMsgList.length === 0){
            component.set('v.sellPropertyAddressInputCheckViewMap.groupClass', 'eswsFeedbackOk');
            return true;
        }else{
            component.set('v.sellPropertyAddressInputCheckViewMap.groupClass', 'eswsFeedbackAlert');
            return false;    
        }
    },
    
    // 売買物件住所情報を登録する
    setSellPropertyAddress: function(component, event, helper, State, City, Street, CityBlock) {
        
        this.setCityOption(component, State, function(response){
            //結果通知後に呼ばれる
            helper.setOption(component, response, "sellPropertyCityId");     
            helper.setSelectValue(component, "sellPropertyStateId",     State);
            helper.setSelectValue(component, "sellPropertyCityId",      City);
            component.set("v.inquiryInput.SellPropertyStreet__c",     Street);
            component.set("v.inquiryInput.SellPropertyCityBlock__c",  CityBlock);
            // 必須チェックを行う
            helper.setRequiredSellPropertyAddress(component, event, helper);
        },{})

    },
    
    // 指定したフィールドの必須エラー設定する 
    requiredCheckField: function(component, field , mapName) {
        
        if(!field || field.length === 0){
            component.set(mapName, 'eswsFeedbackErrorField');
            return false;
        }else{
            component.set(mapName,' eswsFeedbackOkField');
            return true;
        }
    },
    
    //面積チェック
    isArea : function(areaStr){
        var regexp = /^([0-9]\d{0,5})(\.[0-9]{1,2})?$/;
        return regexp.test(areaStr);
    },
})