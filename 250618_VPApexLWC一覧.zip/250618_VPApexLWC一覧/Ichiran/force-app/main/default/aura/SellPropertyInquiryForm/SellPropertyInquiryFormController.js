({
    // タイトルの設定
    getPageTitle : function(component, event, helper) {
        return 'ご売却のご相談、査定のお申込み';
    },
    
    // ページ説明の設定
    getPageDescription : function(component, event, helper) {
        return '物件のご売却や査定等に関するお問合せページです。\n以下の必須項目へご入力いただき、「個人情報の取り扱いについて」に\nご同意の上、「同意して確認画面へ進む」ボタンを押してください。';
    },

    Init : function(component, event, helper) {
        
        // 都道府県選択リストの初期化
        helper.initState(component,"sellPropertyStateId");
        
        // 都道府県選択リストの初期化
        helper.initState(component,"customerStateId");
        
        var inquiryInput = component.get("v.inquiryInput");
        
        if(!inquiryInput ||inquiryInput.length === 0){ 
            
            helper.initLead(component, event, helper, function(){
                component.set("v.inquiryInput.BuildingExclusiveAreaDiv__c","㎡");
                component.set("v.inquiryInput.LandAreaDiv__c","㎡");
            },{})
            
        }else{

            // 売買物件住所の選択リストに値を設定する
            helper.setSellPropertyAddress(component, event, helper, inquiryInput.SellPropertyState__c, inquiryInput.SellPropertyCity__c, inquiryInput.SellPropertyStreet__c, inquiryInput.SellPropertyCityBlock__c );
            
            // お客様住所の選択リストに値を設定する
            helper.setCustomerAddress(component, event, helper, inquiryInput.CustomerState__c,      inquiryInput.CustomerCity__c,     inquiryInput.CustomerStreet__c,     inquiryInput.CustomerCityBlock__c );

            // 間取りタイプの選択リストに値を設定する
            helper.setSelectValue(component, "madoriTypeId", inquiryInput.FloorPlanTypes__c);

            // 戻ってきたときに再度設定する
            helper.getSellPropertyAllMethod(component, event, helper);
            
            if(!inquiryInput.SellPropertyZipCode__c || inquiryInput.SellPropertyZipCode__c.length === 0 ){
                helper.setInputCheckViewMap(component, "v.sellPropertyZipCodeInputCheckViewMap",'eswsFeedbackAlert','eswsFeedbackErrorField','「郵便番号」は必須です。');
            }else{
                helper.setInputCheckViewMap(component, "v.sellPropertyZipCodeInputCheckViewMap", 'eswsFeedbackOk','','');
            }
            
            // 住所の設定を行う
            var zipcode = component.get("v.inquiryInput.CustomerZipCode__c");
            
            if(zipcode){
                helper.zipCodeSearchCallback(component, ( helper.isInteger(zipcode) && zipcode.length === 7), "v.customerZipCodeInputCheckViewMap");      
            }else{
                helper.setInputCheckViewMap(component, "v.customerZipCodeInputCheckViewMap", '','','');
            }

        }
    },
    
    onPropertyTypeCheck :function(component, event, helper){
        const selected = event.getSource().get("v.label");
        
        component.set("v.inquiryInput.PropertyType__c",selected);
        
        helper.setPropertyTypeCheck(component, event, helper);
    },
    
    // マンション入力チェック
    onMansionCheck : function(component, event, helper) {
        const fieldValue = component.get("v.inquiryInput.MansionName__c");
        helper.anyCheck1(component, fieldValue, "v.MansionInputCheckViewMap");
	},
    
    // 必須住所(物件)の値、変更時
    onRequiredSellPropertyAddress : function(component, event, helper) {
        helper.setRequiredSellPropertyAddress(component, event, helper);
	}, 
    
    // 都道府県変更時
	changeSellPropertyState : function(component, event, helper) {
        
        var selected = event.getSource().get("v.value");
        
        helper.setSellPropertyAddress(component, event, helper, selected, "" ,"","");

    },
    // 郵便番号(物件)のフォーカスを外した時
	onSellPropertyZipCodeCheck : function(component, event, helper) {

        var zipcode = component.get("v.inquiryInput.SellPropertyZipCode__c");
        
        if(!zipcode || zipcode.length === 0 ){
            helper.setInputCheckViewMap(component, "v.sellPropertyZipCodeInputCheckViewMap",'eswsFeedbackAlert','eswsFeedbackErrorField','「郵便番号」は必須です。');
        }else{
            helper.zipCodeSearchCallback(component, (helper.isInteger(zipcode) && zipcode.length===7), "v.sellPropertyZipCodeInputCheckViewMap");   
        }


    }, 
    
    // 郵便番号(物件)検索ボタンクリック時
	clickSellPropertyZipCode : function(component, event, helper) {
       
        var zipcode = component.get("v.inquiryInput.SellPropertyZipCode__c");
        
        if(!!zipcode && helper.isInteger(zipcode) && zipcode.length === 7){
            
            helper.zipCodeSearch(component, event, helper, zipcode, function(response){
                
                //結果通知後に呼ばれる
                var retValue = JSON.parse(response);
                
                if(!!retValue){
                    
                    if(!!retValue.results && retValue.results.length > 0){
                        // チェック結果を保持する(戻る押下時に再度外部APIをコールすることでパフォーマンスが悪くなるため)
                        helper.setSearchAddressResult(component, "v.searchSellPropertyAddressResult", retValue.results[0].address1,retValue.results[0].address2,retValue.results[0].address3);
                        // 住所を設定する
                        helper.setSellPropertyAddress(component, event, helper, retValue.results[0].address1, retValue.results[0].address2, retValue.results[0].address3, "");
                    }
                }
            },{})
        }
    },

    // 建物(専有)面積テキスト、変更時
    onBuildingEexclusiveAreaTextCheck : function(component, event, helper) {
        helper.setAreaCheck(component, event, helper);
    },
    
    // 建物(専有)面積ラジオボタン、変更時
    onBuildingEexclusiveAreaRadioCheck : function(component, event, helper) {
        const selected = event.getSource().get("v.label");
        component.set("v.inquiryInput.BuildingExclusiveAreaDiv__c",selected);

    },  
    
    // 土地面積テキスト、変更時
    onLandAreaTextCheck : function(component, event, helper) {
        helper.setAreaCheck(component, event, helper);
    },
    
    // 土地面積ラジオボタン、変更時
    onnLandAreaRadioCheck : function(component, event, helper) {
        
        const selected = event.getSource().get("v.label");
        component.set("v.inquiryInput.LandAreaDiv__c",selected);

    },  
    
    // 間取りテキスト、変更時
    onFloorPlanTextCheck : function(component, event, helper) {

        helper.setFloorPlanTextCheck(component, event, helper);
    },
    
    // 竣工年月、変更時
    onCompletionDateCheck : function(component, event, helper) {
        
        helper.setCompletionDateCheck(component, event, helper);

    },

    // ご希望価格、変更時
    onDesiredPriceCheck : function(component, event, helper) {
        helper.setDesiredPriceCheck(component, event, helper);

    },  
    
    // お買いかえ、変更時
    onShoppingCheck :function(component, event, helper){
        
        const selected = event.getSource().get("v.label");
        component.set("v.inquiryInput.Shopping__c",selected);
        
        helper.setShoppingCheck(component, event, helper);
    },
    
    
    // 売買希望時期、変更時
    onDesiredSaleTimeCheck :function(component, event, helper){
        
        const selected = event.getSource().get("v.label");
        component.set("v.inquiryInput.DesiredSaleTime__c",selected);
        
        helper.setDesiredSaleTimeCheck(component, event, helper);
    },
    
     // ご要望、変更時
    onRequestCheck :function(component, event, helper){
                
        helper.setRequestCheck(component, event, helper);
    },   
    
    // 詳細はこちら押下時処理      
    showDetailMsg : function(component, event, helper){
        
        var detailAddres= document.getElementById("detailAddressSettingMsg");
        
        if (detailAddres.style.display === "block") {
            detailAddres.style.display = "none";
        } else {
            detailAddres.style.display = "block";
        }     
    },
    
    // 同意して確認画面へ進むボタン押下時処理
    next : function (component, event, helper) {
        
        var zipcode = component.get("v.inquiryInput.SellPropertyZipCode__c");
        
        // 売買物件住所の選択リストの値を設定する
        component.set("v.inquiryInput.SellPropertyState__c",  helper.getSelectValue(component, "sellPropertyStateId"));
        component.set("v.inquiryInput.SellPropertyCity__c",   helper.getSelectValue(component, "sellPropertyCityId"));
        
        // お客様住所の選択リストの値を設定する
        component.set("v.inquiryInput.CustomerState__c",      helper.getSelectValue(component, "customerStateId"));
        component.set("v.inquiryInput.CustomerCity__c",       helper.getSelectValue(component, "customerCityId") );
        
        // 間取りタイプの選択リストの値を設定する
        component.set("v.inquiryInput.FloorPlanTypes__c	",      helper.getSelectValue(component, "madoriTypeId"));
        
        const checkAll = helper.getSellPropertyAllMethod(component, event, helper);
        
        if(!zipcode || zipcode.length === 0 ){
            helper.setInputCheckViewMap(component, "v.sellPropertyZipCodeInputCheckViewMap",'eswsFeedbackAlert','eswsFeedbackErrorField','「郵便番号」は必須です。');
            checkAll.push(false);
            helper.next(component, event, helper, checkAll);
        }else{
            helper.zipCodeSearch(component, event, helper, zipcode, function(response){
                //結果通知後に呼ばれる
                var retValue = JSON.parse(response);
                //結果通知後に呼ばれる関数
                checkAll.push(helper.zipCodeSearchCallback(component, (retValue.status === 200 && retValue.results != null), "v.sellPropertyZipCodeInputCheckViewMap")); 
                
                helper.next(component, event, helper, checkAll);
                
            },{}) 
        }
    } 
    
})