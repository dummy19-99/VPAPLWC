({
    showCurrentPageDetail: function(cmp) {
        var currentPageNum = cmp.get("v.CurrentPageNum");
        var allPageNum = cmp.get("v.AllPageNum");
        var foundArticleNum = cmp.get("v.FoundArticleNum");
        var displayNum = cmp.find("DisplayNumVal").get("v.value");
        var beforeDisplayNum = cmp.get("v.LastDisplayNumSelectedValue");
        var articles = cmp.get("v.articles");
        var displayCount = currentPageNum * displayNum;
        var startNum = 0;
        var endNum = 0;
        var displayArticles = [];
        
        if(beforeDisplayNum != displayNum && beforeDisplayNum != 0){
            var beforeStartNum = ((currentPageNum - 1) * beforeDisplayNum) + 1;
            currentPageNum = Math.ceil(beforeStartNum / displayNum);
            cmp.set('v.CurrentPageNum', currentPageNum);
        }
        
        if(foundArticleNum < displayCount) {
            startNum = ((currentPageNum - 1) * displayNum) + 1;
            endNum = foundArticleNum;
        } else {
            startNum = ((currentPageNum - 1) * displayNum) + 1;
            endNum = currentPageNum * (displayNum );
        }
        
        var text = foundArticleNum + "件中 " + startNum + " ～ " + endNum + " 件を表示しています";
        
        cmp.set('v.FoundArticleText', text);
        
        for(var i = startNum ; i <= endNum ; i++) {
            displayArticles.push(articles[i - 1]);
        }
        
        cmp.set('v.LastDisplayNumSelectedValue', displayNum);
        cmp.set('v.DisplayArticles', displayArticles);
    },
    changeButtonSortColor: function(cmp) {
        // true=up false=down
        var sortUpDown = cmp.get("v.SortUpDown");
        if(sortUpDown == "true"){
            cmp.find("upSortButton").set("v.disabled", "true");
            cmp.find("downSortButton").set("v.disabled", "false");
        } else {
            cmp.find("upSortButton").set("v.disabled", "false");
            cmp.find("downSortButton").set("v.disabled", "true");
        }
    },
    showButtonPage: function(cmp) {
        var allPageNum = parseInt(cmp.get("v.AllPageNum"));
        var currentPageNum = cmp.get("v.CurrentPageNum");
        var displayPageButton = cmp.get("v.DisplayPageButton");
        var fixedNumber = 5;
        var DisplayPageButton = [];
        var maxDisplay = currentPageNum + Math.floor(fixedNumber / 2);
        var minDisplay = currentPageNum - Math.floor(fixedNumber / 2);
        
        if(allPageNum <= fixedNumber) {
            for(var i = 1 ; i <= allPageNum ; i++) {
                DisplayPageButton.push(i);
            }
        } else if(minDisplay < 1 && maxDisplay < allPageNum) {
            for(var i = 1 ; i <= fixedNumber ; i++) {
                DisplayPageButton.push(i);
            }
        } else if(minDisplay >= 1 && maxDisplay < allPageNum) {
            for(var i = minDisplay ; i <= maxDisplay ; i++) {
                DisplayPageButton.push(i);
            }
        } else if(minDisplay >= 1 && maxDisplay >= allPageNum) {
            for(var i = allPageNum - fixedNumber ; i <= allPageNum ; i++) {
                DisplayPageButton.push(i);
            }
        }
        
        cmp.set('v.DisplayPageButton', DisplayPageButton);
    },
    sortArticles: function(cmp, DescOrAec, sortField) {
        var articles = cmp.get("v.articles");
        articles.sort(function(a, b){
            switch(sortField) {
                case 0:
                    var value1 = new Date(a.CreatedDate);
                    var value2 = new Date(b.CreatedDate);
                    break;
                case 1:
                    var value1 = a.Price__c;
                    var value2 = b.Price__c;
                    break;
                case 2:
                    var value1 = a.ExpectedYield__c;
                    var value2 = b.ExpectedYield__c;
                    break;
                case 3:
                    var value1 = a.BuildingAge__c;
                    var value2 = b.BuildingAge__c;
                    break;
                case 4:
                    var value1 = a.Area__c;
                    var value2 = b.Area__c;
                    break;
                case 5:
                    var value1 = a.FloorPlan__c;
                    var value2 = b.FloorPlan__c;
                    break;
                case 6:
                    var value1 = a.LandArea__c;
                    var value2 = b.LandArea__c;
                    break;
                case 7:
                    var value1 = a.TransportationFacilities__c;
                    var value2 = b.TransportationFacilities__c;
                    break;
                case 8:
                    var value1 = a.PropertyLocation__c;
                    var value2 = b.PropertyLocation__c;
                    break;
            }
            
            if(DescOrAec == "true") {
                if(value1 == null && value2 != null) {
                    return -1
                } else if(value1 != null && value2 == null) {
                    return 1
                } else if(value1 == null && value2 == null){
                    return 0
                }
                
                return value1 > value2 ? -1 : value1 < value2 ? 1 : 0;
            } else {
                if(value1 == null && value2) {
                    return 1
                } else if(value1 && value2 == null) {
                    return -1
                } else if(value1 == null && value2 == null){
                    return 0
                }
                
                return value1 > value2 ? 1 : value1 < value2 ? -1 : 0;
            }
        });
        
        cmp.set('v.articles', articles);
    }
})