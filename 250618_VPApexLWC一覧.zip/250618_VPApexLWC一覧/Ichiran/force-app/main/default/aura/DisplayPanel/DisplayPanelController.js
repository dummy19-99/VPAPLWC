({
	init: function (cmp, event, helper) {
        var displayNumOp = {
            selectedDisplayNumVal: 6,
            displayNum: [
                { label: '6件', value:6, selected: true},
                { label: '12件', value:12},
                { label: '30件', value:30},
                { label: '60件', value:60}
            ]
        };

        var displaySortOp = {
            selectedDisplaySortVal: 0,
            displaySort: [
                { label: '新着', value:0, selected: true},
                { label: '価格', value:1},
                { label: '利回り', value:2},
                { label: '築年月', value:3},
                { label: '面積（専有・建物）', value:4},
                { label: '間取り', value:5},
                { label: '土地', value:6},
                { label: '交通', value:7},
                { label: '所在地', value:8}
            ]
        };

        cmp.set('v.DisplayNumSelectedValue', displayNumOp.selectedDisplayNumVal);
        cmp.set('v.DisplayNumOptions', displayNumOp.displayNum);
        cmp.set('v.DisplaySortSelectedValue', displaySortOp.selectedDisplaySortVal);
        cmp.set('v.DisplaySortOptions', displaySortOp.displaySort);
        cmp.set('v.SortUpDown', false);

        var displayNum = cmp.find("DisplayNumVal").get("v.value");
        var action = cmp.get("c.getAllArticles");
        //20190330 追加 miyoshi
        //20200527 新着物件追加
        action.setParams({ "type" : cmp.get("v.RecordType"), "syueki" : cmp.get("v.Syueki"),"limitCount" : cmp.get("v.RecordLimit"),"newProperty" : cmp.get("v.NewProperty")});
        //action.setParams({ "type" : cmp.get("v.RecordType"), "syueki" : cmp.get("v.Syueki"),"limitCount" : cmp.get("v.RecordLimit")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var articles = response.getReturnValue();
                
                for(var i = 0 ; i < articles.length ; i++) {
                    articles[i].checked = false;
                }
                cmp.set('v.articles', articles);
                cmp.set('v.CurrentPageNum', 1);
                cmp.set('v.AllPageNum', Math.ceil(response.getReturnValue().length / displayNum));
                cmp.set('v.FoundArticleNum', response.getReturnValue().length);

                helper.sortArticles(cmp, "false", 0);
                helper.showCurrentPageDetail(cmp);
                helper.changeButtonSortColor(cmp);
                helper.showButtonPage(cmp);
            }
            else if (state === "INCOMPLETE") {
                console.log("INCOMPLETE")
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });

        $A.enqueueAction(action);
    },
    changeArticleList: function(cmp, event, helper) {
        var displayNum = cmp.find("DisplayNumVal").get("v.value");
        var foundArticleNum = cmp.get("v.FoundArticleNum");

        cmp.set('v.AllPageNum', Math.ceil(foundArticleNum / displayNum));

        helper.showCurrentPageDetail(cmp);
        helper.showButtonPage(cmp);
    },
    sortByField: function(cmp, event, helper) {
        var displayNum = parseInt(event.getSource().get("v.value"));
        var upSortButtonBool = cmp.find("upSortButton").get("v.disabled");
        var downSortButtonBool = cmp.find("downSortButton").get("v.disabled");

        if(downSortButtonBool == "true") {
            helper.sortArticles(cmp, "false", displayNum);
        } else if(upSortButtonBool == "true") {
            helper.sortArticles(cmp, "true", displayNum);
        }

        helper.showCurrentPageDetail(cmp);
    },
    sortAscDesc: function(cmp, event, helper) {
        var sortBoolean = event.getSource().get("v.value");
        var displayNum = parseInt(cmp.find("DisplaySortVal").get("v.value"));

        cmp.set("v.SortUpDown", sortBoolean);

        helper.changeButtonSortColor(cmp);
        helper.sortArticles(cmp, sortBoolean, displayNum);
        helper.showCurrentPageDetail(cmp);
    },
    nextOrPrev: function(cmp, event, helper) {
        var nextOrPreVal = parseInt(event.getSource().get("v.value"));
        var currentPageNum = cmp.get("v.CurrentPageNum");
        var allPageNum = cmp.get("v.AllPageNum");

        if(nextOrPreVal == -2) {
            cmp.set("v.CurrentPageNum", 1);
        } else if(nextOrPreVal == 2) {
            cmp.set("v.CurrentPageNum", allPageNum);
        } else if(nextOrPreVal == -1) {
            currentPageNum = currentPageNum <= 1 ? 1 : currentPageNum - 1;
            cmp.set("v.CurrentPageNum", currentPageNum);
        } else if(nextOrPreVal == 1) {
            currentPageNum = currentPageNum >= allPageNum ? allPageNum : currentPageNum + 1;
            cmp.set("v.CurrentPageNum", currentPageNum);
        }

        helper.showCurrentPageDetail(cmp);
        helper.showButtonPage(cmp);
    },
    goSpecificPage: function(cmp, event, helper) {
        var pageNum = parseInt(event.getSource().get("v.label"));
        cmp.set("v.CurrentPageNum", pageNum);
        helper.showCurrentPageDetail(cmp);
    },
    handleComponentEvent: function(cmp, event, helper) {
        var displayNum = cmp.find("DisplayNumVal").get("v.value");
        var message = event.getParam("whereSOQLString");
        var action = cmp.get("c.getArticles");

        action.setParams({ soqlString : message });

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                cmp.set('v.articles', response.getReturnValue());
                cmp.set('v.CurrentPageNum', 1);
                cmp.set('v.AllPageNum', Math.ceil(response.getReturnValue().length / displayNum));
                cmp.set('v.FoundArticleNum', response.getReturnValue().length);

                helper.sortArticles(cmp, "false", 0);
                helper.showCurrentPageDetail(cmp);
                helper.changeButtonSortColor(cmp);
                helper.showButtonPage(cmp);
            }
            else if (state === "INCOMPLETE") {
                console.log("INCOMPLETE")
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });

        $A.enqueueAction(action);
    },
    showSpinner : function (component, event, helper) {
        if(document.getElementById("DisplayPanel").style) {
            document.getElementById("DisplayPanel").style.display = "none";
        }

        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");

        evt.setParams({ isVisible : true });
        evt.fire();
    },
    doneWaiting : function (component, event, helper) {
        var dispalyPanelElement = document.getElementById("DisplayPanel");
        var loadingElement = document.getElementById("loading");
        
        if(dispalyPanelElement && loadingElement) {
            dispalyPanelElement.style.display = "block";
            loadingElement.style.display = "none";
            
            var spinner = component.find('spinner');
            var evt = spinner.get("e.toggle");
            
            evt.setParams({ isVisible : false });
            evt.fire();
        }
    },
    updateCheckBox : function(cmp, event, helper) {
        var message = event.getParam("whereSOQLString");
        var message_split = message.split("_");
        var name = message_split[0];
        var value = message_split[1];
        var articles = cmp.get("v.articles");
        
        var changeIndex = articles.findIndex(function(element) {
            return element.Id == name
        });
        
        if(changeIndex != -1){
            articles[changeIndex].checked = (value == 'true');            
            cmp.set("v.articles", articles);
            helper.showCurrentPageDetail(cmp);
        }
        
	},
    submitInquiryId : function(cmp, event, helper) {
        var stringId = ""
        var articles = cmp.get("v.articles");        
        var count = 0;
        
        for(var i = 0 ; i < articles.length ; i++) {
            if(articles[i].checked === true) {
                if(count != 0) {
                    stringId += ",";
                }
                
                stringId += articles[i].Id;
                count++;
                
                if(count > 10) {
                    alert("一度に問い合わせ可能な物件は10件までです。");
                    return;
                }
            }
        }
        
         if(count === 0){
            alert('物件が選択されていません。');
            return;
        }
        
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/s"));
        
        window.open(baseURL + '/s/propertyinquiryformdisplay?propertyIds=' + stringId, "_blank");
    }
})