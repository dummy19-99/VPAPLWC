({
    /* 20190516 不具合対応 goto
     * 共通コンポーネントに処理を移動する
    updateInquiryCheckList : function(cmp, event, helper) {
        var cmpEvent = cmp.getEvent("updateInquiryCheckbox");
        var source = event.getSource();
        var name = source.get("v.name");
        var checked = source.get("v.checked"); 
        
        cmpEvent.setParams({
            "whereSOQLString" : name + "_" + checked});
        cmpEvent.fire();
    },*/
    
    showDetailPage : function(cmp, event, helper) {
       
        var article = cmp.get('v.article');
        helper.showDetailCommonPage(cmp, event, helper, article);
        /*  共通コンポーネントに処理を移動する
        if(article){
            var urlString = window.location.href;
            var baseURL = urlString.substring(0, urlString.indexOf("/s"));
            
            // サムネイル有り無し判定(有り：true 無し:false)
            var withThumbnail = !(!article.ContentDocumentLinks || article.ContentDocumentLinks.length === 0);
            
            // レコードタイプが設定されていない場合
            if(!article.Type__c || article.Type__c.length === 0 ){
                alert(article.Type__c);
                alert('異常なデータです。管理者にお問い合わせください。')
            }else{
                if(article.Type__c === '区分'){
                    window.open(baseURL + '/s/PropertyDetailsMansion?propertyId=' + article.Id + '&' + 'withThumbnail=' + withThumbnail , "_blank");
                }else if(article.Type__c === '戸建'){
                    window.open(baseURL + '/s/PropertyDetailsDetachedHouse?propertyId=' + article.Id + '&' + 'withThumbnail=' + withThumbnail , "_blank");
                }else if(article.Type__c === '土地'){
                    window.open(baseURL + '/s/PropertyDetailsLand?propertyId=' + article.Id + '&' + 'withThumbnail=' + withThumbnail , "_blank");
                }
                //収益物件    
                else{
                    window.open(baseURL + '/s/PropertyDetailsDetachedHouse?propertyId=' + article.Id + '&' + 'withThumbnail=' + withThumbnail , "_blank");
                }
            }
        } */      
    },
    
})