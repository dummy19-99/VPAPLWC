({
	updateInquiryCheckList : function(cmp, event, helper) {
        var cmpEvent = cmp.getEvent("updateInquiryCheckbox");
        var source = event.getSource();
        var name = source.get("v.name");
        var checked = source.get("v.checked"); 
        
        cmpEvent.setParams({
            "whereSOQLString" : name + "_" + checked});
        cmpEvent.fire();
    },
    
})