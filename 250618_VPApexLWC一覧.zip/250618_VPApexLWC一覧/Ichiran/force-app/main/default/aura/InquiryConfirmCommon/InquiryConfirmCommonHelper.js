({
    // 子エレメントを設定する
    setChildElement : function(mainElement, childElement){
        mainElement.appendChild(childElement);
    },
    
    // お客様名を設定する
    setCustomerName: function(component, helper, auraId){
       
        var auraElement =  component.find(auraId).getElement();
         
        var mainElement = component.mainElement =  document.createElement('p')
        
        mainElement.innerText += component.get("v.inquiryInput.LastName") + '　' + component.get("v.inquiryInput.FirstName");
        mainElement.innerText += '/';
        mainElement.innerText += component.get("v.inquiryInput.LastNameKana__c") + '　' + component.get("v.inquiryInput.FirstNameKana__c");
        
        helper.setChildElement(auraElement, mainElement);
    },
    
    // ご連絡先を設定する
    setContactInformation: function(component, helper, auraId){
       
        var auraElement =  component.find(auraId).getElement();
         
        var getSetElement  = function(title, data, helper){
            
            var mainElement = component.mainElement =  document.createElement('p');
            var childElement1 = document.createElement('span');
            var childElement2 = document.createElement('span');
            
            mainElement.className  = "cf";
            
            childElement1.className  = "eswsSubLabel";
            childElement1.innerText = title;
            
            childElement2.innerText = data;
            
            helper.setChildElement(mainElement, childElement1);
            helper.setChildElement(mainElement, childElement2);
            
            return mainElement;
        };
        
        var email = component.get("v.inquiryInput.Email");
        var Phone = component.get("v.inquiryInput.Phone");
        
        if(email){
            var emailElement = getSetElement('メール', email, helper);
            helper.setChildElement(auraElement, emailElement); 
        }
        
        if(Phone){
            var phoneElement = getSetElement('電話番号', Phone, helper);
            helper.setChildElement(auraElement, phoneElement); 
        }
            
    },
})