({
    // ページの説明
    getPageDescription : function(component, event, helper) {
        return '以下の内容をご確認の上、「この内容で送信する」ボタンを押してください。';
	},
    
    previous : function (component, event, helper) {
        
        var inputData = component.get("v.inquiryInput");
        
        var setEvent = component.getEvent("gotoPrevious");
        setEvent.setParams({
            "acquiredDataList": JSON.stringify(component.get("v.propertyViewList")),
            "inquiryInput":    JSON.stringify(component.get("v.inquiryInput"))
        });
        setEvent.fire();
        document.getElementById("pageWrap").scrollIntoView(true);
    },
    
    next : function (component,event, helper){
        // Apex
        var action = component.get("c.insertInquiryInputData");
        
        var inquiryInput = component.get("v.inquiryInput");
        var propertyViewList = component.get("v.propertyViewList");

        action.setParams({
            "inquiryInput" : (!inquiryInput || inquiryInput.length === 0) ? null :  JSON.stringify(inquiryInput),
            "acquiredDataList" : (!propertyViewList || propertyViewList.length === 0) ? null :  JSON.stringify(propertyViewList)
        });
        
        action.setCallback(this, function(response) { 
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var setEvent = component.getEvent("gotoNext");
                
                var value = response.getReturnValue();
                
                if(value.hasError){
                    const event = $A.get("e.force:showToast");
                    event.setParams({
                        type: "error",
                        mode : "sticky",
                        message: value.errorMessages[0],
                    });
                    event.fire();
                }else{
                    setEvent.setParams({
                        "acquiredDataList": null,
                        "inquiryInput": null
                    });
                    setEvent.fire();  
                }
            } else if (state === "ERROR") {
                alert("例外エラーが発生しました");
            }
        });
        $A.enqueueAction(action);
        document.getElementById("pageWrap").scrollIntoView(true);
	},
})