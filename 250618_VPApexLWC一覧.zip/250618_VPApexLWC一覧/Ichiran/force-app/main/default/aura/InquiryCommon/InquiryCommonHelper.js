({
    // 対象のauraIDにテキストを設定する
    setElementText : function(component, auraId, msg) {
        var element = component.find(auraId).getElement();
        element.innerText = msg;
	},
    
})