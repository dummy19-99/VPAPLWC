({
	getPageTitle : function(component, event, helper) {
		return '';
	},
    
    getPageDescription : function(component, event, helper) {
        return '';
	},
    
    dispContactInfo : function(component, event, helper) {
        return true;
	},
    
    // スピナーの表示
    showSpinner: function(component, event, helper) {
        component.set("v.Spinner", true); 
    },
    
    // スピナーの非表示
    hideSpinner : function(component,event,helper){
        component.set("v.Spinner", false);
    }
})