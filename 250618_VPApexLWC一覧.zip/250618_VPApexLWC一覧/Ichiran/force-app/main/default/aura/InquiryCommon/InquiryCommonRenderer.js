({
    afterRender: function(component, helper) {
        this.superAfterRender();
        
        // ページタイトルを設定
        helper.setElementText(component, "pageTitleId",component.getConcreteComponent().getPageTitle());
        
        // ページ説明を設定
        helper.setElementText(component, "pageDescriptionId",component.getConcreteComponent().getPageDescription());
        
        // ご連絡先表示/非表示
        var dispContactInfo = component.getConcreteComponent().dispContactInfo();
        
        if(dispContactInfo === false){
            $A.util.addClass(component.find('contactInfoId'), 'eswsHidden');
        }
    }
})