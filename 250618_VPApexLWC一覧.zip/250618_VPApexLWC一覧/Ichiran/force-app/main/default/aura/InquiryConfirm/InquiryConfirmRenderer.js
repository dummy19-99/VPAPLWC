({
    afterRender : function(component, helper) {
        
        this.superAfterRender();    
           
        // お客様名を設定する
        helper.setCustomerName(component, helper, "customerNameId");
        
        // 連絡先を設定する
        helper.setContactInformation(component, helper, "contactInformationId");
        
    },
})