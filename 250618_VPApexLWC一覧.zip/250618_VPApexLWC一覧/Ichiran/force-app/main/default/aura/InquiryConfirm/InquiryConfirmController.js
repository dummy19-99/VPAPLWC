({
    // タイトルの設定
    getPageTitle : function(component, event, helper) {
        return 'お問合せ';
    },
})