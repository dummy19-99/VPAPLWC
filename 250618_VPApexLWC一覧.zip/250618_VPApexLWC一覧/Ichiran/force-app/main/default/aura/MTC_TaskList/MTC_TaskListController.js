({
    //初期表示：トランのタスクの詳細ボタンを表示
    doInit : function(cmp, evt, helper){
        var bool = false;
        var thisTask = cmp.get("v.taskMaster");
        var prefix = cmp.get("v.prefix");
        //トランのタスクかをprefixで判定
        if(!$A.util.isUndefinedOrNull(thisTask.Id) && thisTask.Id.substring(0,3) === prefix){
            bool = true;
        }
        cmp.set("v.isTran", bool);
    },
    //妥当性確認
    handleValidEvent : function (cmp, evt, helper){
        var bool = false;
        var Event = $A.get("e.c:thorowValid");
        var validExpense = cmp.find('taskform').reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        // If we pass error checking, do some real work
        if(validExpense){
            bool = true;
        }
       	Event.setParams({"valid":bool});
        Event.fire();    
    },
    //レコードの詳細ページに繊維
    edit : function(cmp, evt, helper) {
        //複数回イベントの発生を防止するため
        //ボタンが押されたことを残す
        cmp.set("v.isEdited",true);
        var selectedRow = cmp.get("v.taskMaster");
        var firstId = selectedRow.Id;
        //詳細ページに繊維するイベント
        var editRecordEvent = $A.get("e.force:editRecord");
        editRecordEvent.setParams({
            "recordId": firstId
        });
        editRecordEvent.fire();
    },
    //レコードの詳細ページで操作結果
    refreshAll : function(cmp, evt, helper){
        var evnetType = evt.getParam("type");
        //保存が押された場合、再読み込みを要求する
        if(cmp.get("v.isEdited") && evnetType === "SUCCESS" ){
            var taskListEvt = $A.get("e.c:TaskListEvt");
            taskListEvt.fire();
        }
    }
})