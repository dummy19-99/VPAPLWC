({
    getPageTitle : function(component, event, helper) {
		return 'お問合せ';
	},
	getMsg: function(component, event, helper) {
		return '内容を確認のうえ、弊社担当者より後ほどご連絡を差し上げます。その他にも気になることがありましたらお気軽にお問合せください。\nお問い合わせありがとうございました。';
	},      
})