({
    // 物件情報取得
	getArticleInfo : function(component, event) {
        
        var articleIds = this.getUrlParameter("propertyIds");
        
        // Apex
        var action = component.get("c.getArticleInfo");

        action.setParams({
            "articleIds": articleIds
        });
        action.setCallback(this, function(data) {
            
            var rslt = data.getState();
            
            if (rslt === "SUCCESS"){
                component.set("v.propertyViewList", data.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
     
    // 画面遷移時のパラメータを取得する
    getUrlParameter : function(sParam) {
        
        var result = new Array();
        
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
        
        var sURLMulitiple = sPageURL.split('&');

        if(!sURLMulitiple){
            return result;
        }
        
        var sURLVariablesMap = new Map();
        
        for(var i =0 ; i < sURLMulitiple.length; i ++){
            var temp = sURLMulitiple[i].split('=');
            if(temp && temp.length > 1){
                sURLVariablesMap.set(temp[0], temp[1]);
            }
        }
      
        if(!sURLVariablesMap){
            return result;
        }
        
        for (const key of sURLVariablesMap.keys()) {
            
            if (key === sParam) {
                
                var sParameterName = sURLVariablesMap.get(key).split(',');
                
                if(sParameterName != null && sParameterName.length > 0){
                    for(var i =0 ; i < sParameterName.length; i ++){
                        if(sParameterName[i] != null && sParameterName[i].length > 0){
                            result.push(sParameterName[i]); 
                        }
                    }
                }
            }
        }
                

        return result;
    },
    
    // チェックボックス入力チェック
    setInquiryContentsInputCheck : function(component, event) {
        
        var inquiryInput = component.get("v.inquiryInput");
        
        if(inquiryInput.InquiryContentsCheck1__c 
        || inquiryInput.InquiryContentsCheck2__c 
        || inquiryInput.InquiryContentsCheck3__c 
        || inquiryInput.InquiryContentsCheck4__c 
        || inquiryInput.InquiryContentsCheck5__c 
        || inquiryInput.InquiryContentsCheck6__c ){
            this.setInputCheckViewMap(component, "v.inquiryContentsInputCheckViewMap",'eswsFeedbackOk','','');
            return true;
        }else{
            this.setInputCheckViewMap(component, "v.inquiryContentsInputCheckViewMap",'eswsFeedbackAlert','eswsFeedbackErrorField','お問合せ内容を入力してください。');
            return false;
        }
    },
    
    // 備考エラー状態を設定
    setRemarksCheck : function(component, event, helper) {
        const fieldValue = component.get("v.inquiryInput.Remarks__c");
        return helper.anyCheck1(component, fieldValue, "v.remarksInputCheckViewMap");
	},

})