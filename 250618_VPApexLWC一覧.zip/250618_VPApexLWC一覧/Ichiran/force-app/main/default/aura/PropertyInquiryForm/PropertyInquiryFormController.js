({
    
    getPageTitle : function(component, event, helper) {
		return '売買物件のお問合せ';
	},
    
    getPageDescription : function(component, event, helper) {
		return '売買物件のお問合せページです。\n以下の必須項目へご入力いただき、「個人情報の取り扱いについて」に\nご同意の上、「同意して確認画面へ進む」ボタンを押してください。';
	},
    
    dispContactInfo : function(component, event, helper) {
        return false;
	},
    
    // 初期化
    Init : function(component, event, helper) {
        
        // 都道府県選択リストの初期化
        helper.initState(component,"customerStateId");

        // リードの初期化
        var inquiryInput = component.get("v.inquiryInput");
                
        if(!inquiryInput || inquiryInput.length === 0){
            var visitBooking = helper.getUrlParameter("visitBooking");     
            
            helper.initLead(component, event, helper, function(){
                if(visitBooking && visitBooking[0]){
                    component.set("v.inquiryInput.InquiryContentsCheck1__c", true);
                    helper.setInquiryContentsInputCheck(component, event);
                }
            },{})
        }else{
            
            // 住所の設定を行う
            var zipcode = component.get("v.inquiryInput.CustomerZipCode__c");
            
            if(zipcode){
                helper.zipCodeSearchCallback(component, (helper.isInteger(zipcode) && zipcode.length === 7), "v.customerZipCodeInputCheckViewMap");
            }else{
                helper.setInputCheckViewMap(component, "v.customerZipCodeInputCheckViewMap", '','','');
            }
            
            helper.setInquiryContentsInputCheck(component, event, helper);
            helper.setRemarksCheck(component, event, helper);
            
            helper.setSelectValue(component, "customerStateId",     inquiryInput.CustomerState__c);
            helper.setSelectValue(component, "customerCityId",      inquiryInput.CustomerCity__c);
        }

        // 物件の初期値取得
        var propertyViewList = component.get("v.propertyViewList"); 
        
        if(!propertyViewList ||propertyViewList.length === 0){
            helper.getArticleInfo(component, event);
        }

    },
    
    // お問い合わせ内容チェック
	onInquiryContentsInputCheck : function(component, event, helper) {
        // お問い合わせ内容入力チェック
        helper.setInquiryContentsInputCheck(component, event, helper);
    },
    
    // 備考チェック
    onRemarksCheck : function(component, event, helper) {
        // 備考チェック
        helper.setRemarksCheck(component, event, helper);
	},
    // 同意して確認画面へ進むボタン押下
    next : function (component, event, helper) {

        component.set("v.inquiryInput.CustomerState__c", helper.getSelectValue(component, "customerStateId"));
        component.set("v.inquiryInput.CustomerCity__c",  helper.getSelectValue(component, "customerCityId") );

        const checkAll=[helper.setInquiryContentsInputCheck(component, event, helper),
                        helper.setRemarksCheck(component, event, helper)                      
                       ];

        helper.next(component, event, helper, checkAll);
    }    
})