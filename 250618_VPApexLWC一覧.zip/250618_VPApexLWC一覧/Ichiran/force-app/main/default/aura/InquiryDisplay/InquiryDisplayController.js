({
    
    gotoPrevious: function(component, event, helper)
    {
        component.set( "v.routeIndex", component.get("v.routeIndex")-1 );
        helper.setComponent(component, event, helper);
    },
    
    gotoNext: function(component, event, helper)
    {
        component.set( "v.routeIndex", component.get("v.routeIndex")+1 );
        helper.setComponent(component, event, helper);
    },
    
    render : function (component, event, helper) {
        
        component.set("v.routeIndex", 0);
        helper.setComponent(component, event, helper);

    }
})