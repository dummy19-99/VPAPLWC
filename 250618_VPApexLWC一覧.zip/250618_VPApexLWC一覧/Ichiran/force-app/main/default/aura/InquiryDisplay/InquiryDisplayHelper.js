({
	setComponent : function(component, event, helper) {
        
        var routeList = component.get("v.routeList");
        
        var routeIndex = component.get("v.routeIndex"); 
        
        var cmpName = routeList[routeIndex];
        
        var inputBindData = event.getParam("inquiryInput") == null ?  null : JSON.parse(event.getParam("inquiryInput"));
        
        var acquiredDataList = event.getParam("acquiredDataList") == null ?  null : JSON.parse(event.getParam("acquiredDataList"));
        
        $A.createComponent(
            "c:" + cmpName,
            {
                "aura:Id": cmpName,
                "inquiryInput": inputBindData,
                "propertyViewList":acquiredDataList,         
            },
            function(newCmp){
                if (component.isValid()) {
                    var body = component.get("v.body");
                    body.pop();
                    body.push(newCmp);
                    component.set("v.body", body);
                }else if (status === "INCOMPLETE") {
                    console.log("No response from server or client is offline.");
                }else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                }
                
            }
        );
	},  
})