({
    //親コンポーネント（TemplateEditor_Base）から「タスク更新」押下時、入力項目の妥当性を確認
    handleValidEvent : function(cmp, evt, helper) {
		var bool = false;
        //親コンポーネント（TemplateEditor_Base）に妥当性を送るためのイベント
        var Event = $A.get("e.c:thorowValid");
        //妥当性確認
        var validExpense = cmp.find('taskform').reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        // If we pass error checking, do some real work
        if(validExpense){
            bool = true;
        }
       	Event.setParams({"valid":bool});
        Event.fire();
	}
})