({
    
	sliderInit : function(component, event, helper) {
        // 物件の初期値取得
        helper.getDocumentInfo(component, event, helper);
	},
    
    loadSwiper: function(component, event, helper){

        var mySwiper = new Swiper(' ' + '.swiper-container', {
            initialSlide: 0,
            slidesPerView: 4,
            spaceBetween: 10,
            observer:true,
            breakpoints: {
                1520: {
                    slidesPerView: 4,
                },                
                1140: {
                    slidesPerView: 3,
                },                
                760: {
                    slidesPerView: 2,
                },
                380: {
                    slidesPerView: 1,
                },
            },
            
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev'
            },
            
            pagination: {
                el: '.swiper-pagination',
                type: 'fraction',
                clickable: true
            },
            
            scrollbar: {
                el: '.swiper-scrollbar'
            }
        });
    },
    
    clickThumbnailing: function(component, event, helper) {
        var modal = document.getElementById('myModal');
        modal.classList.remove("hide-modal");
        
        var target = event.target;
        var rowdata = target.getAttribute("data-row-data");
        
        var modalImg = document.getElementById("img01");
        modalImg.src = rowdata;
        
        helper.zoomEvent(component, event, helper);


    },
    
    close: function(component, event, helper) {
        var modal = document.getElementById('myModal');

        modal.classList.add("hide-modal");
        
        var modalImg = document.getElementById("img01");
        modalImg.src = '';
    }
})