({
    
    // 物件情報取得
    getDocumentInfo : function(component, event, helper){
        
        // ArticleID
        var recordId = component.get("v.recordId");
        
        // Apex
        var action = component.get("c.getDocumentInfo");

        action.setParams({
            "recordId": recordId
        });
        action.setCallback(this, function(data) {
            
            var rslt = data.getState();
            
            if (rslt === "SUCCESS"){
                component.set("v.contentDistributionList",data.getReturnValue());          
            }
            component.set("v.loading", false);    
        });
        $A.enqueueAction(action);
    },
    
    zoomEvent: function(component, event, helper){
                
        var appEvent = $A.get("e.c:sliderZoom");

        appEvent.fire();
    },
})